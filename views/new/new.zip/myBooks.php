<div id="page_content">
    <div id="page_content_inner">
        <h4 class="heading_a uk-margin-bottom">My Books</h4>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-large-8-10">
                <div class="md-card uk-margin-medium-bottom">
                    <div class="md-card-content">
                        <div class="dt_colVis_buttons"></div>
                        <table data-step="1" data-intro="Here you can read the e-books you purchased." id="dt_tableExporta" class="uk-table" cellspacing="0" width="100%">
                            <tr>
                                <th>#           </th>
                                <th data-step="2" data-intro="This column represents the title of e-book">Title       </th>
                                <th>Description </th>
                                <th>Image       </th>
                                <th data-step="3" data-intro="From here you can read your e-book'">Read        </th>
                            </tr>
                            <?php if(!empty($myBooks)){ ?>
                                <?php $i=1; foreach($myBooks as $val){ ?>
                                    <tr>
                                        <td><?= $i; ?></td>
                                        <td><?= $val['title'] ?></td>
                                        <td><?= $val['desc'] ?></td>
                                        <td><img src="<?= base_url("assets_f/img")."/".$val['image'] ?>" alt="" style="width:100px"/></td>
                                        <td><a href="<?= base_url("assets_f/img")."/".$val['file'] ?>" target="_blank">Download</a></td>
                                    </tr>
                                <?php $i++; } ?>
                            <?php }else{ ?>
                                <tr>
                                    <th style="text-align: center" colspan="5">No e-books purchased yet</th>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>

            </div>
            <?php require_once('advert_v.php'); ?>
        </div>
    </div>
</div>

