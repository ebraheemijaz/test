<!doctype html>
<!--[if lte IE 9]> <html class="lte-ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="en"> <!--<![endif]-->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="google-signin-client_id" content="667428527963-u21s5caeb2ja69ej723ajc652lrfaev0.apps.googleusercontent.com">

    <!-- Remove Tap Highlight on Windows Phone IE -->
    <meta name="msapplication-tap-highlight" content="no"/>
    <link rel="icon" type="image/png" href="<?= base_url('assets_f/logo.png') ?>" sizes="16x16">
    <link rel="icon" type="image/png" href="<?= base_url('assets_f/logo.png') ?>" sizes="32x32">
    <title>Membership Management System - Login</title>
    <link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500' rel='stylesheet' type='text/css'>
    <!-- uikit -->
    <link rel="stylesheet" href="<?= base_url('assets_new') ?>/bower_components/uikit/css/uikit.almost-flat.min.css"/>
    <!-- altair admin login page -->
    <link rel="stylesheet" href="<?= base_url('assets_new') ?>/assets/css/login_page.min.css" />


<!--    <script src="https://ucarecdn.com/libs/widget/3.1.2/uploadcare.full.min.js" charset="utf-8"></script>-->
<!--    <script>-->
<!--        UPLOADCARE_PUBLIC_KEY = '2bf1b53f7fa658553ab0';-->
<!--    </script>-->
    <style>
        input[type='password'], input[type='text']{
            background: white !important;
            border-radius: 5px !important;
        }
        label{
            font-weight: bold;
        }
        .heading_a{
            color:white !important;
        }
        .uk-close:after{
            color:white !important;
        }

        ::-webkit-input-placeholder { /* WebKit, Blink, Edge */
            font-weight: bold;
        }
        :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
            font-weight: bold;
            opacity:  1;
        }
        ::-moz-placeholder { /* Mozilla Firefox 19+ */
            font-weight: bold;
            opacity:  1;
        }
        :-ms-input-placeholder { /* Internet Explorer 10-11 */
            font-weight: bold;
        }
        ::-ms-input-placeholder { /* Microsoft Edge */
            font-weight: bold;
        }
    </style>
</head>
<body class="login_page">
    <div class="login_page_wrapper">
        <div class="md-card1" id="login_card">
            <div class="md-card-content large-padding" id="login_form">
                <div class="login_heading">
                    <div class="user_avatar" style="width:160px;height:160px;background-image: url(<?= base_url('assets_f/logoW.png') ?>);background-size: 100% 100%">
                    </div>
                </div>
                <?= form_open("home/dologin",array("autocomplete"=>"off")) ?>
                    <div class="uk-form-row">
<!--                        <label for="login_username">Email Address</label>-->
                        <input placeholder="Email Address" class="md-input" type="text" id="login_username" value="<?= (isset($_COOKIE['mmsOnline1231'])) ? $_COOKIE['mmsOnline1231'] : ''; ?>" autocomplete="off" name="email" />
                    </div>
                    <div class="uk-form-row">
                        <input class="md-input" placeholder="Password" type="password" id="login_password" value="<?= (isset($_COOKIE['mmsOnline1232'])) ? $_COOKIE['mmsOnline1232'] : ''; ?>" name="password" />
                        <p id="errorrrr" style="text-align:center;"><?php if(!empty($msg)){ ?><?= $msg; ?><?php } ?></p>
                    </div>
                    <div class="uk-margin-medium-top">
                        <span class="icheck-inline">
                            <input type="checkbox" name="remember" value="1" id="login_page_stay_signed" data-md-icheck />
                            <label for="login_page_stay_signed"  class="inline-label" style="color:white">Stay signed in</label>
                        </span>
                        <button id="loginHereButton" class="md-btn md-btn-primary md-btn-block md-btn-large">Sign In</button>
                    </div>
                    <div class="uk-grid uk-grid-width-1-2 uk-grid-small uk-margin-top">

<!--                        <div><a href="#" onclick="testAPI();" class="md-btn md-btn-block md-btn-facebook" data-uk-tooltip="{pos:'bottom'}" title="Sign in with Facebook"><i class="uk-icon-facebook uk-margin-remove"></i></a></div>-->
                        <div>
<!--                            <div onclick="gS();" class="md-btn md-btn-block md-btn-gplus" data-onsuccess="onSignIn" data-uk-tooltip="{pos:'bottom'}" title="Sign in with Google+"><i class="uk-icon-google-plus uk-margin-remove"></i></div>-->
<!--                            <div id="testingGoogle"></div>-->
<!--                                <div style="" data-onsuccess="onSignIn" class="g-signin2" data-theme="dark"></div>-->
                            <script>

                                function gS(){
                                    $(".abcRioButtonContentWrapper").click();
                                }
                            </script>
                        </div>
                    </div>
                    <div class="uk-margin-top">
<!--                        <a href="#" id="login_help_show" class="uk-float-right">Having Trouble?</a>-->

                        <p style="text-align: center">
                            <span class="icheck-inline">
                                <a href="#" id="password_reset_show">Forgot Password?</a>
                            </span>
                        </p>
                        <p style="text-align: center">
                            <span  id="signup_form_show" href="#" class="icheck-inline">
                                <a href="" class="uk-float-right">Don't have an account? Sign up!</a>
                            </span>
                        </p>
                        <p style="text-align: center">
                            <span class="icheck-inline">
                                <a href="<?= base_url(); ?>/TERMS AND CONDITIONS FOR THE  APPLICATION.pdf" target="_blank" class="uk-float-right">Terms & Conditions</a>
                            </span>
                        </p>

                    </div>
                <?= form_close() ?>
            </div>
            <div class="md-card-content large-padding uk-position-relative" id="login_help" style="display: none">
                <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>

                <h2 class="heading_b uk-text-success" style="color:white !important;">Can't create my account?</h2>
                <p style="color:white">To become a member, ensure you have obtained a valid code from your local church administration office to create an account.The validation code is essential to begin your membership registration process.</p>
                <h2 class="heading_b uk-text-success" style="color:white !important;">Can't log in?</h2>
                <p style="color:white">Here is a quick information to get you back in to your account as quickly as possible. </p>
                <p style="color:white">First, try the easiest thing: if you remember your password but it isn’t working, make sure your Caps Lock is turned off, and your access email is spelt correctly, and then try again.</p>
                <p style="color:white">If your password still isn’t working, it’s time to reset your password.</p>
            </div>

            <div class="md-card-content large-padding" id="login_password_reset" style="display: none">
                <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
                <h2 class="heading_a uk-margin-large-bottom">Reset password</h2>
                <?= form_open('home/forgotPwd'); ?>
                    <div class="uk-form-row">
<!--                        <label for="login_email_reset">Your email address</label>-->
                        <input class="md-input" type="text" placeholder="Your Email Address" id="login_email_reset" name="email" />
                        <p style="text-align: center;display:none;color:white;" id="errorForget">Please Check your email to reset your password</p>
                    </div>
                    <div class="uk-margin-medium-top">
                        <button type="button" onclick="forgotPwd()" class="md-btn md-btn-primary md-btn-block">Reset password</button>
                    </div>
                </form>

            </div>
            <div class="md-card-content large-padding" id="register_form" style="display: none">
                <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
                <h2 class="heading_a uk-margin-medium-bottom">Create an account</h2>
                <?= form_open_multipart('home/doRegister') ?>
                    <div class="uk-form-row" id="codeFieldDiv">
<!--                        <label for="register_username">Enter Validation Code</label>-->
                        <input class="md-input" placeholder="Enter Validation Code" type="text" id="codec" name="code" />
                        <p id="errorCode" style="text-align: center"></p>
                        <button type="button" onclick="validateCode()" id="val" class="md-btn md-btn-info">Validate</button>
                        <p style="text-align: center">
                            <span  id="login_help_show" href="#" class="icheck-inline">
                                <a href="" class="uk-float-right">Having Trouble?</a>
                            </span>
                        </p>
                    </div>
                    <div id="regField" style="display: none;">
                        <div class="uk-grid uk-grid-width-1-2 uk-grid-small uk-margin-top">
                            <div><a href="#" onclick="testAPIreg();" class="md-btn md-btn-block md-btn-facebook" data-uk-tooltip="{pos:'bottom'}" title="Sign in with Facebook"><i class="uk-icon-facebook uk-margin-remove"></i></a></div>
                            <div class="g-signin2" data-onsuccess="onSignUp"></div>
                            <!--<div><a href="#" class="md-btn md-btn-block md-btn-gplus" data-uk-tooltip="{pos:'bottom'}" title="Sign in with Google+"><i class="uk-icon-google-plus uk-margin-remove"></i></a></div>-->
                        </div>
                        <hr/>
                        <p style="text-align: center !important; font-weight: bold">OR</p>
                        <hr/>
                        <div class="uk-form-row">
                            <select id="select_demo_4" class="md-input" name="title">
                                <option value="Mr">Mr</option>
                                <option value="Mrs">Mrs</option>
                                <option value="Miss">Miss</option>
                                <option value="Elder">Elder</option>
                                <option value="Pastor">Pastor</option>
                                <option value="Prophet">Prophet</option>
                                <option value="Prophetess">Prophetess</option>
                                <option value="Reverend">Reverend</option>
                                <option value="Deacon">Deacon</option>
                                <option value="Deaconess">Deaconess</option>
                                <option value="Dr">Dr</option>
                                <option value="Professor">Professor</option>
                            </select>
                        </div>
                        <div class="uk-form-row">
                            <label for="register_username">First Name</label>
                            <input class="md-input" type="text" id="register_username" name="fname" />
                        </div>
                        <div class="uk-form-row">
                            <label for="register_username">Last Name</label>
                            <input class="md-input" type="text" id="register_username" name="lname" />
                        </div>
                        <div class="uk-form-row">
                            <label for="register_username">Email</label>
                            <input class="md-input" type="text" id="register_username" name="email" />
                        </div>
                        <div class="uk-form-row">
                            <label for="register_username">Mobile No (Along with country code)</label>
                            <input class="md-input" type="text" id="register_username" name="mobileNo" />
                        </div>
                        <div class="uk-form-row">
                            <select id="select_demo_4" class="md-input" name="gander">
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                        <div class="uk-form-row">

                            <div id="file_upload-drop" class="uk-file-upload">
                                <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" id="blah" alt=""/>
                                <a class="uk-form-file md-btn">Select Profile Image
                                    <input id="file_upload-select" type="file"  accept="image/*" required name="image">
                                </a>
                            </div>
                            <div id="file_upload-progressbar" class="uk-progress uk-hidden">
                                <div class="uk-progress-bar" style="width:0">0%</div>
                            </div>
<!--                            <input type="file" accept="image/*" required name="image"/>-->
<!--                            <input type="hidden" role="uploadcare-uploader" data-images-only />-->
                        </div>

                        <div class="uk-form-row">
                            Birthday
                            <div class="uk-grid" data-uk-grid-margin>
                                <div class="uk-width-medium-1-2">
                                    <select name="birth_month" id="month" class="md-input">
                                        <option value='1'>January</option>
                                        <option value='2'>February</option>
                                        <option value='3'>March</option>
                                        <option value='4'>April</option>
                                        <option value='5'>May</option>
                                        <option value='6'>June</option>
                                        <option value='7'>July</option>
                                        <option value='8'>August</option>
                                        <option value='9'>September</option>
                                        <option value='10'>October</option>
                                        <option value='11'>November</option>
                                        <option value='12'>December</option>
                                    </select>
                                </div>
                                <div class="uk-width-medium-1-2">
                                    <select name="birth_date" class="md-input" id="birth_date">
                                        <?php for($i=1;$i<=31;$i++){ ?>
                                            <option value="<?= $i ?>"><?= $i ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="uk-form-row">
                            Age Group
                            <select name="age_group" class="md-input">
                                <option value="9"> 0 - 9 </option>
                                <option value="18"> 10 - 18 </option>
                                <option value="29"> 19 - 29 </option>
                                <option value="39"> 30 - 39 </option>
                                <option value="49"> 40 - 49 </option>
                                <option value="50"> Above 50 </option>
                            </select>
                        </div>

                        <div class="uk-form-row">
                            <label for="register_password">Password</label>
                            <input class="md-input" type="password" onkeyup="checkPasswd()" id="register_password" />
                        </div>
                        <div class="uk-form-row">
                            <label for="register_password_repeat">Repeat Password</label>
                            <input class="md-input" type="password" onkeyup="checkPasswd()" id="register_password_repeat" name="password" />
                        </div>
                        <div class="uk-form-row">
                            <span class="icheck-inline">
                                <input type="checkbox" name="first_time" value="yes" id="login_page_stay_signed" data-md-icheck />
                                <label for="login_page_stay_signed"  class="inline-label">Are you a first timer?</label>
                            </span>
                        </div>
                        <div class="uk-margin-medium-top">
                            <button type="button" id="doreg" class="md-btn md-btn-primary md-btn-block md-btn-large">Sign Up</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
        <!--<div class="uk-margin-top uk-text-center">
            <a id="signup_form_show" href="#">Create an account</a>
        </div>-->
    </div>
    <script src="<?= base_url('assets_new') ?>/assets/js/common.min.js"></script>
    <script src="<?= base_url('assets_new') ?>/assets/js/uikit_custom.min.js"></script>
    <script src="<?= base_url('assets_new') ?>/assets/js/altair_admin_common.min.js"></script>
    <script src="<?= base_url('assets_new') ?>/assets/js/pages/login.min.js"></script>
    <script src="<?= base_url('assets_new') ?>/assets/js/pages/forms_file_upload.min.js"></script>

    <script>
//        $(window).load(function(){
//            setTimeout(function(){
//                $('#login_password').attr('type','password');
//            },500);
//        });
        if (typeof(Storage) !== "undefined") {
            var root = document.getElementsByTagName('html')[0],
                theme = localStorage.getItem("altair_theme");
            if(theme == 'app_theme_dark' || root.classList.contains('app_theme_dark')) {
                root.className += ' app_theme_dark';
            }
        }
        function forgotPwd(){
            altair_helpers.content_preloader_show('md');
            $("#errorForget").css("display","none");
            var email = $("#login_email_reset").val();
            if(email == ""){
                $("#errorForget").html("Please Insert Valid Email Address");
                altair_helpers.content_preloader_hide();
            }else{
                $.post("<?= site_url('home/forgotPwd'); ?>",{email:email},function(e){
                    altair_helpers.content_preloader_hide();
                    if(e == "error"){
                        e = "Email not registered";
                    }else if(e == "sent"){
                        e = "Please Check your email to reset your password"
                    }else{
                        e = "An Error Occurred";
                    }
                    $("#errorForget").html(e);
                    $("#errorForget").css("display","");
                });
            }
        }
        function validateCode(){
            var c = $("#codec").val();
            $.post("<?= site_url('home/ajax/validCode'); ?>",{code:c},function(e){
                console.log(e);
                if(e == "Invalid"){
                    $("#errorCode").css("display","");
                        $("#errorCode").html("Code Invalid Or Already Used");
                }else{
                    $("#regField").css("display","");
                    $("#codeFieldDiv").css("display","none");
                    //$("#codec").attr("readonly","");
                    //$("#val").css("display","none");
                }
            });
        }
        function checkPasswd(){
            var p1 = $("#register_password").val();
            var p2 = $("#register_password_repeat").val();
            if(p1 != ''){
                if(p1 != p2){
                    $("#doreg").attr("type","button");
                    $("#doreg").html("Passwords Doesn't Match");
                }else{
                    if(p1.length >= 6){
                        $("#doreg").attr("type","submit");
                        $("#doreg").html("Create");
                    }else{
                        $("#doreg").attr("type","button");
                        $("#doreg").html("Password Too Short");
                    }

                }
            }else{
                $("#doreg").attr("type","button");
                $("#doreg").html("Password Empty");
            }
        }
    </script>
    <script src="https://apis.google.com/js/platform.js" async defer></script>
    <script>
        function onSignIn(googleUser) {
console.log("Test");
            var profile = googleUser.getBasicProfile();
            var email = profile.getEmail();
            $.post("<?= site_url('home/ajaxLogin') ?>",{email:email},function(e){
                if(e == 'True'){
                    window.location.href = "<?= site_url('home'); ?>";
                }else{
                    signOut();

                    $("#errorrrr").html(e);
                }
            });
        }
        function onSignUp(googleUser) {
            console.log("Signup");

            var code = $("#codec").val();
            var profile = googleUser.getBasicProfile();
            var name = profile.getName();
            var email = profile.getEmail();
            $.post("<?= site_url('home/ajaxRegister') ?>",{code:code,email:email,fname:name},function(e){
                if(e == 'True'){
                    window.location.href = "<?= site_url('home'); ?>";
                }else{
                    signOut();
                    window.location.href = "<?= site_url('home'); ?>";
                    //$("#errorrrr").html(e);
                }
            });
        }
        function signOut(){
            var auth2 = gapi.auth2.getAuthInstance();
            auth2.signOut().then(function () {
                console.log('User signed out.');
            });
        }
    </script>
    <script>
        function statusChangeCallback(response) {
            console.log('statusChangeCallback');
            console.log(response);
            if (response.status === 'connected') {
                //testAPI();
                console.log("Connected");
            } else {
                document.getElementById('status').innerHTML = 'Please log ' +
                'into this app.';
            }
        }

        function checkLoginState() {
            FB.getLoginStatus(function(response) {
                statusChangeCallback(response);
            });
        }

        window.fbAsyncInit = function() {
            FB.init({
                appId      : '1451990008166435',
                cookie     : true,  // enable cookies to allow the server to access
                xfbml      : true,  // parse social plugins on this page
                version    : 'v2.8' // use graph api version 2.8
            });
            FB.getLoginStatus(function(response) {
                statusChangeCallback(response);
            });
        };
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));

        function testAPI() {
            FB.login();
            console.log('Welcome!  Fetching your information.... ');
            FB.api('/me?fields=id,name,email', function(response) {
                if (typeof response.id !== 'undefined') {
                    var email = response.id;
                    if(typeof response.email != 'undefined'){
                        email = response.email;
                    }
                    $.post("<?= site_url('home/ajaxLogin') ?>",{email:email},function(e){
                        console.log(e);
                        if(e == 'True'){
                            window.location.href = "<?= site_url('home'); ?>";
                        }else{
                            signOut();
                            $("#errorrrr").html(e);
                        }
                    });
                }
            });
        }
        function testAPIreg() {
            FB.login();
            console.log('Welcome!  Fetching your information.... ');
            FB.api('/me?fields=id,name,email', function(response) {
                if (typeof response.id !== 'undefined') {
                    var email = response.id;
                    if(typeof response.email != 'undefined'){
                        email = response.email;
                    }
                    var code = $("#codec").val();
                    var name = response.name;

                    $.post("<?= site_url('home/ajaxRegister') ?>",{code:code,email:email,fname:name},function(e){
                        if(e == 'True'){
                            window.location.href = "<?= site_url('home'); ?>";
                        }else{
                            signOut();
                            window.location.href = "<?= site_url('home'); ?>";
                            //$("#errorrrr").html(e);
                        }
                    });
                }
            });
        }
    </script>
    <script>
        <?php if(isset($_COOKIE['mmsOnline1231']) AND empty($msg)){ ?>
            $("#loginHereButton").click();
        <?php } ?>
    </script>
    <script>
        setTimeout(function(){
            gapi.signin2.render('testingGoogle', {
                'scope': 'profile email',
                'width': 140,
                'height': 35,
                'longtitle': false,
                'onsuccess': onSignIn
            });
        },2000);
    </script>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#file_upload-select").change(function(){
            console.log(1);
            readURL(this);
        });
    </script>
</body>
</html>