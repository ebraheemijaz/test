<div id="page_content">
    <div id="page_content_inner">

        <div class="uk-width-large-8-10 uk-container-center">

            <div class="md-card md-card-single">
                <div class="md-card-toolbar">
                    <div class="md-card-toolbar-actions">
                        <i class="md-icon material-icons" id="toggleAll">&#xe8f2;</i>
                    </div>
                    <h3 class="md-card-toolbar-heading-text large">
                        Help Center
                    </h3>
                </div>
                <div class="md-card-content padding-reset">
                    <h4 class="heading_c full_width_in_card">Login Videos</h4>
                    <div class="uk-accordion uk-accordion-alt hierarchical_slide help_accordion" data-slide-children="h3" data-slide-context=".md-card-content">
                        <h3 class="uk-accordion-title">How to signup</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">How to reset your password?</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">How to change your password?</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                    </div>
                    <h4 class="heading_c full_width_in_card">Profile Update Videos</h4>
                    <div class="uk-accordion uk-accordion-alt hierarchical_slide help_accordion" data-slide-children="h3" data-slide-context=".md-card-content">
                        <h3 class="uk-accordion-title">Learn more about "My Profile"</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Learn more about "General Settings"</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Learn more about the notification area</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Birthday greetings and age update</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                    </div>
                    <h4 class="heading_c full_width_in_card">Dashboard Videos</h4>
                    <div class="uk-accordion uk-accordion-alt hierarchical_slide help_accordion" data-slide-children="h3" data-slide-context=".md-card-content">
                        <h3 class="uk-accordion-title">Using the feedback</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Need help/FAQs</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Shortcuts to "My Profile" area</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">How to advertise?</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Adding and viewing events on your calendar</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Word Log shortcut access</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Easy access to New Messages</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Learn more on Orders Accepted, Revenue, Orders Completed, Upcoming Revenue</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>

                    </div>

                    <h4 class="heading_c full_width_in_card">Menu Videos</h4>
                    <div class="uk-accordion uk-accordion-alt hierarchical_slide help_accordion" data-slide-children="h3" data-slide-context=".md-card-content">
                        <h3 class="uk-accordion-title">Bible</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Live Event</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Word log</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Bulletin</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Testimony</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Prayer Request</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Donate</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Bookstore</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Search</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">My Buddies</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Inbox</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Business Page</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Manage Offers</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>
                        <h3 class="uk-accordion-title">Feedback</h3>
                        <div class="uk-accordion-content">
                            <p>Video will go here.</p>
                        </div>

                    </div>

                </div>
            </div>

        </div>

    </div>
</div>