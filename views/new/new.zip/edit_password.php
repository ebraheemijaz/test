<?php
$v = $userAdmin[0];
?>
<style>
    .row {
        margin-right: -15px;
        margin-left: -15px;
    }
    .row:before,
    .row:after{
        display: table;
        content: " ";
    }
    .row:after{
        clear: both;
    }

</style>
    <div id="page_content">
        <div id="page_content_inner">
            <?php require_once('advert_h.php'); ?>

            <form action="<?= site_url('home/accSettings'); ?>" class="uk-form-stacked" method="post" id="user_edit_form" enctype="multipart/form-data">
                <div class="uk-grid" data-uk-grid-margin>
                    <div class="uk-width-large-1-1">
                        <div class="md-card">
                            <div class="user_heading" data-uk-sticky="{ top: 48, media: 960 }">

                                <div class="user_heading_avatar fileinput fileinput-new" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail">
                                        <?php $image = (empty($v['image'])) ? base_url('assets_f/img/business/avatar.jpg') : base_url('assets_f/img/business')."/".$v['image'] ; ?>
                                        <img src="<?= $image ?>" alt="user avatar"/>
                                    </div>
                                    <div class="fileinput-preview fileinput-exists thumbnail"></div>
                                </div>
                                <div class="user_heading_content">
                                    <h2 class="heading_b">
                                        <span class="uk-text-truncate" id="user_edit_uname" style="font-weight: bold;font-size:26px"><?= $v['fname']." ".$v['lname'] ?></span>
                                    </h2>
                                </div>
                            </div>
                            <div class="user_content">
                                <ul id="user_edit_tabs" class="uk-tab" data-uk-tab="{connect:'#user_edit_tabs_content'}">
                                    <li class="uk-active"><a href="#">Change Password</a></li>
                                </ul>
                                <ul id="user_edit_tabs_content" class="uk-switcher uk-margin">
                                    <li>
                                        <div class="uk-margin-top">
                                            <?php if(!empty($msg)){ ?>
                                                <p style="text-align: center;font-size: 18px;color:red;"><span class="alert alert-warning"><?= $msg ?></span></p>
                                            <?php } ?>
                                            <h3 class="full_width_in_card heading_c">
                                                Change Password
                                            </h3>
                                            <div class="uk-grid" data-uk-grid-margin>
                                                <div class="uk-width-medium-1-2">
                                                    <label for="user_edit_uname_control">Current Password</label>
                                                    <input class="md-input" name="c_pwd" type="text" />
                                                </div>
                                            </div>
                                            <div class="uk-grid" data-uk-grid-margin>
                                                <div class="uk-width-medium-1-2">
                                                    <label for="user_edit_uname_control">New Password</label>
                                                    <input class="md-input" type="text" name="new_pwd"/>
                                                </div>
                                                <div class="uk-width-medium-1-2">
                                                    <label for="user_edit_uname_control">Confirm Password</label>
                                                    <input class="md-input" type="text" name="cf_pwd"/>
                                                </div>
                                            </div>
                                            <div class="uk-grid" data-uk-grid-margin>
                                                <div class="uk-width-medium-1-1">
                                                    <input class="md-btn md-btn-primary" value="Change" style="float: right" type="submit" />
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>

            </form>

        </div>
    </div>


