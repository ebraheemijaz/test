<?php
$v = $userAdmin[0];
?>
<style>
    .uk-tooltip-small{
        width: 4000px !important;
    }
</style>
    <div id="page_content">
        <div id="page_content_inner">
            <?php require_once('advert_h.php'); ?>
            <!-- circular charts -->
            <div class="uk-grid uk-grid-small" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
                <div class="uk-width-medium-1-1">
                    <?php
                    $todayMonth = date("n");
                    $todayDate = date("j");
                    if($todayDate == $v['birth_date'] && $todayMonth == $v["birth_month"]){ ?>
                        <?php if(!empty($userAdmin)){ ?>
                            <?php if($userAdmin[0]['id'] != $v['id']){
                                $name = $v['fname']." ".$v['lname'];
                                $msg = $name . " have their Happy Birthday Today!";
                            }else{
                                $msg = "Happy Birthday and we Wish you Long Life and Prosperity!";
                            }
                            ?>
                        <?php }else{ $name = $v['fname']." ".$v['lname'];$msg = "Its ".$name . "'s Happy Birthday Today!"; } ?>
                        <p style="text-align:center;font-weight: bold;font-size:18px; ">
                            <img style="width:50px" src="<?= base_url('birthday.png') ?>" alt="">
                            <?= $msg ?>
                            <?php if(empty($birthnotifdesktop)){ ?>
                                <span id="updateAgeGroupButton" style="font-size:14px;"><a href="<?= site_url('home/view/edit_profile?action=age') ?>">Click to update your age group</a></span>
                            <?php } ?>
                        </p>
                        <br>
                    <?php } ?>
                </div>
                <div class="uk-width-medium-4-10" >
                    <div>
                        <div data-step="6" data-intro="Profile Card" class="md-card">
                            <div style="background: 3 !important;" class="md-card-head md-bg-light-blue-600">
                                <div class="md-card-head-menu" data-uk-dropdown="{pos:'bottom-right'}">
                                    <i class="md-icon material-icons md-icon-light">&#xE5D4;</i>
                                    <div class="uk-dropdown uk-dropdown-small">
                                        <ul class="uk-nav">
                                            <li><a href="<?= site_url('home/member') ?>/<?= $userAdmin[0]['id'] ?>">User profile</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="uk-text-center">
                                    <?php $image = (empty($userAdmin[0]['image'])) ? base_url('assets_f/img/tutor.png') : base_url('assets_f/img/business')."/".$userAdmin[0]['image']; ?>
                                    <a href="<?= $image ?>" data-uk-lightbox="{group:'user-photos1'}">
                                        <img class="md-card-head-avatar" src="<?= $image ?>" alt=""/>
                                    </a>
                                </div>
                                <h3 class="md-card-head-text uk-text-center md-color-white">
                                    <?= $userAdmin[0]['fname']." ".$userAdmin[0]['lname'] ?>
                                    <span><?= $userAdmin[0]['email'] ?></span>
                                </h3>
                            </div>
                            <div class="md-card-content">
                                <ul class="md-list md-list-addon">
                                    <li>
                                        <div class="md-list-addon-element">
                                            <i class="md-list-addon-icon material-icons">&#xE158;</i>
                                        </div>
                                        <div class="md-list-content">
                                            <span class="md-list-heading"><?= $userAdmin[0]['email'] ?></span>
                                            <span class="uk-text-small uk-text-muted">Email</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="md-list-addon-element">
                                            <i class="md-list-addon-icon material-icons">&#xE0CD;</i>
                                        </div>
                                        <div class="md-list-content">
                                            <span class="md-list-heading"><?= $userAdmin[0]['homeNo'] ?></span>
                                            <span class="uk-text-small uk-text-muted">Phone</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="md-list-addon-element">
                                            <i class="md-list-addon-icon  material-icons">&#xE8A5;</i>
                                        </div>
                                        <div class="md-list-content">
                                            <span class="md-list-heading"><?= $userAdmin[0]['mobileNo'] ?></span>
                                            <span class="uk-text-small uk-text-muted">Mobile</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="uk-width-medium-6-10" >
                    <div class="md-card">
                        <div id="clndr_events"  data-step="7" data-intro="Calendar" class="clndr-wrapper">
                            <script>
                                // calendar events
                                clndrEvents = [
                                    <?php $i=1; foreach($reminders as $k=>$v){ ?>
                                    {
                                        date:"<?= $v['date'] ?>",
                                        title:"<?= $v['title'] ?>",
                                        //url:"<?//= $v['link'] ?>",
                                        timeStart:"<?= $v['timeStart'] ?>",
                                        timeEnd:"<?= $v['timeEnd'] ?>"
                                    }
                                    <?php if($i != count($reminders)){ echo ","; } ?>
                                    <?php $i++; } ?>
                                ]
                            </script>
                            <script id="clndr_events_template" type="text/x-handlebars-template">
                                <div class="md-card-toolbar">
                                    <div class="md-card-toolbar-actions">
                                        <i data-step="8" data-intro="Create Event" class="md-icon clndr_add_event material-icons">&#xE145;</i>
                                        <i data-step="9" data-intro="GoTo Today Date" class="md-icon clndr_today material-icons">&#xE8DF;</i>
                                        <i data-step="10" data-intro="Previous Month" class="md-icon clndr_previous material-icons">&#xE408;</i>
                                        <i data-step="11" data-intro="Next Month" class="md-icon clndr_next material-icons uk-margin-remove">&#xE409;</i>
                                    </div>
                                    <h3 class="md-card-toolbar-heading-text">
                                        {{ month }} {{ year }}
                                    </h3>
                                </div>
                                <div class="clndr_days">
                                    <div class="clndr_days_names">
                                        {{#each daysOfTheWeek}}
                                        <div class="day-header">{{ this }}</div>
                                        {{/each}}
                                    </div>
                                    <div class="clndr_days_grid">
                                        {{#each days}}
                                        <div class="{{ this.classes }}" {{#if this.id }} id="{{ this.id }}" {{/if}}>
                                        <span>{{ this.day }}</span>
                                    </div>
                                    {{/each}}
                                </div>
                                </div>
                                <div class="clndr_events">
                                    <i class="material-icons clndr_events_close_button">&#xE5CD;</i>
                                    {{#each eventsThisMonth}}
                                    <div class="clndr_event" data-clndr-event="{{ dateFormat this.date format='YYYY-MM-DD' }}">
                                        <a href="{{ this.url }}">
                                            <span class="clndr_event_title">{{ this.title }}</span>
                                            <span class="clndr_event_more_info">
                                                {{~dateFormat this.date format='MMM Do'}}
                                                {{~#ifCond this.timeStart '||' this.timeEnd}} ({{/ifCond}}
                                                {{~#if this.timeStart }} {{~this.timeStart~}} {{/if}}
                                                {{~#ifCond this.timeStart '&&' this.timeEnd}} - {{/ifCond}}
                                                {{~#if this.timeEnd }} {{~this.timeEnd~}} {{/if}}
                                                {{~#ifCond this.timeStart '||' this.timeEnd}}){{/ifCond~}}
                                            </span>
                                        </a>
                                    </div>
                                    {{/each}}
                                </div>
                            </script>
                        </div>
                        <div class="uk-modal" id="modal_clndr_new_event">
                            <div class="uk-modal-dialog">
                                <div class="uk-modal-header">
                                    <h3 class="uk-modal-title">New Event</h3>
                                </div>
                                <div class="uk-margin-bottom">
                                    <label for="clndr_event_title_control">Event Title</label>
                                    <input type="text" class="md-input" id="clndr_event_title_control" />
                                </div>
                                <div class="uk-margin-medium-bottom">
                                    <label for="clndr_event_link_control">Event Link</label>
                                    <input type="text" class="md-input" id="clndr_event_link_control" />
                                </div>
                                <p><input type="radio" checked onclick="changeEventTypee(this.value)" name="eventType" value="one">Is this event for one day?</p>
                                <p><input type="radio" onclick="changeEventTypee(this.value)" name="eventType" value="multiple">Is this event for more than one day?</p>

                                <div id="oneDayEvent">
                                    <div class="uk-grid uk-grid-width-medium-1-3 uk-margin-large-bottom" data-uk-grid-margin>
                                        <div>
                                            <div class="uk-input-group">
                                                <span class="uk-input-group-addon"><i class="uk-input-group-icon uk-icon-calendar"></i></span>
                                                <label for="clndr_event_date_control">Event Date</label>
                                                <input class="md-input" type="text" id="clndr_event_date_control" data-uk-datepicker="{format:'YYYY-MM-DD', minDate: '<?= date("Y-m-d"); ?>' }">
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-input-group">
                                                <span class="uk-input-group-addon"><i class="uk-input-group-icon uk-icon-clock-o"></i></span>
                                                <label for="clndr_event_start_control">Event Start</label>
                                                <input class="md-input" type="text" id="clndr_event_start_control" data-uk-timepicker>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-input-group">
                                                <span class="uk-input-group-addon"><i class="uk-input-group-icon uk-icon-clock-o"></i></span>
                                                <label for="clndr_event_end_control">Event End</label>
                                                <input class="md-input" type="text" id="clndr_event_end_control" data-uk-timepicker>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="multiDayEvent">
                                    <div class="uk-grid uk-grid-width-medium-1-2 uk-margin-large-bottom" data-uk-grid-margin>
                                        <div>
                                            <div class="uk-input-group">
                                                <span class="uk-input-group-addon"><i class="uk-input-group-icon uk-icon-calendar"></i></span>
                                                <label for="clndr_event_date_control">Event Start Date</label>
                                                <input class="md-input" type="text" id="clndr_event_date_control" data-uk-datepicker="{format:'YYYY-MM-DD', minDate: '<?= date("Y-m-d"); ?>' }">
                                            </div>
                                        </div>
                                        <div>
                                            <div class="uk-input-group">
                                                <span class="uk-input-group-addon"><i class="uk-input-group-icon uk-icon-calendar"></i></span>
                                                <label for="clndr_event_date_control">Event Start Date</label>
                                                <input class="md-input" type="text" id="clndr_event_end_date_control" data-uk-datepicker="{format:'YYYY-MM-DD', minDate: '<?= date("Y-m-d"); ?>' }">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="uk-modal-footer uk-text-right">
                                    <button type="button" class="md-btn md-btn-flat uk-modal-close">Close</button>
                                    <button type="button" class="md-btn md-btn-flat md-btn-flat-primary" onclick="addReminder();" id="clndr_new_event_submit">Add Event</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div >
            </div>
            <div data-step="5" data-intro="Notifications Area" class="uk-grid uk-grid-small uk-grid-width-small-1-2 uk-grid-width-large-1-4 uk-grid-width-xlarge-1-4 uk-text-center" data-uk-grid-margin>
                <div>
                    <div class="md-card md-card-hover md-card-overlay">
                        <div class="md-card-content">
                            <a href="<?= site_url('home/view/view_word') ?>">
                                <div class="epc_chart" data-percent="37" data-bar-color="#607d8b">
                                    <span class="epc_chart_icon"><i class="material-icons">&#xE865;</i></span>
                                </div>
                            </a>
                        </div>
                        <div class="md-card-overlay-content">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <a href="<?= site_url('home/view/view_word') ?>">
                                    <h3>
                                        Word Log
                                    </h3>
                                </a>
                            </div>
                            This is your shortcut access to all the preachers’ text format messages in the church.
                        </div>
                    </div>
                </div>
                <div >
                    <div class="md-card md-card-hover md-card-overlay">
                        <a href="<?= site_url('home/view') ?>/chat">
                            <div class="md-card-content">
                                <div class="epc_chart" data-percent="76" data-bar-color="#03a9f4">
                                    <span class="epc_chart_icon"><i class="material-icons">&#xE0BE;</i></span>
                                </div>
                            </div>
                            <div class="md-card-overlay-content">
                                <div class="uk-clearfix md-card-overlay-header">
                                    <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                    <a href="<?= site_url('home/view') ?>/chat">
                                        <h3>
                                            New Messages
                                        </h3>
                                    </a>
                                </div>
                                Your easy access to new messages from your buddies and the admin.
                            </div>
                        </a>
                    </div>
                </div>
                <div>
                    <div class="md-card md-card-hover md-card-overlay md-card-overlay">
                        <div class="md-card-content" id="canvas_1">
                            <div class="epc_chart" data-percent="37" data-bar-color="#9c27b0">
                                <span class="epc_chart_icon"><i class="material-icons">&#xE85D;</i></span>
                            </div>
                        </div>
                        <div class="md-card-overlay-content">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <h3>
                                    Calendar Logs
                                </h3>
                            </div>
                            <p>
                                Easy access to the information of all upcoming events by the church and events uploaded by you in your calendar area.
                            </p>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="md-card md-card-hover md-card-overlay">
                        <a href="<?= site_url('home/view/manage_offers') ?>?type=received">
                        <div class="md-card-content uk-flex uk-flex-center uk-flex-middle">
                            <span class="peity_conversions_large peity_data">5,3,9,6,5,9,7</span>
                        </div>
                        <div class="md-card-overlay-content">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <a href="<?= site_url('home/view/manage_offers') ?>?type=received">
                                    <h3>
                                        Orders To Do
                                    </h3>
                                </a>
                            </div>
                            This area shows the current orders you have to do for your customers.
                        </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="uk-grid uk-grid-width-large-1-4 uk-grid-width-medium-1-2 uk-grid-small " data-uk-grid-margin>
                <div>
                    <div class="md-card" data-step="1" data-intro="Statistics of orders you received" data-uk-tooltip="{cls:'uk-tooltip-small',pos:'bottom'}" title="Total order you accepted">
                        <div class="md-card-content">
                            <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class="peity_visitors peity_data">5,3,9,6,5,9,7</span></div>
                            <span class="uk-text-muted uk-text-small">Orders Accepted</span>
                            <h2 class="uk-margin-remove"><span class="countUpMe">0<noscript><?= $acceptedOffers[0]['total'] ?></noscript></span></h2>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="md-card" data-step="2" data-intro="Statistics of Revenue you earned" data-uk-tooltip="{cls:'uk-tooltip-small',pos:'bottom'}" title="Total Money you made">
                        <div class="md-card-content">
                            <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class="peity_sale peity_data">5,3,9,6,5,9,7,3,5,2</span></div>
                            <span class="uk-text-muted uk-text-small">Revenue</span>
                            <h2 class="uk-margin-remove">£ <span class="countUpMe">0<noscript><?php $revenuea = 0; foreach($revenue as $val){ $revenuea += $val['amount']; } echo $revenuea; ?></noscript></span></h2>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="md-card" data-step="3" data-intro="Statistics of orders you received and completed" data-uk-tooltip="{cls:'uk-tooltip-small',pos:'bottom'}" title="Orders you have completed">
                        <div class="md-card-content">
                            <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class="peity_orders peity_data">0/100</span></div>
                            <span class="uk-text-muted uk-text-small">Orders Completed</span>
                            <h2 class="uk-margin-remove"><span class="countUpMe">0<noscript>0</noscript></span>%</h2>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="md-card" data-step="4" data-intro="Statistics of revenue you will earn when you complete your pending orders" data-uk-tooltip="{cls:'uk-tooltip-small',pos:'bottom'}" title="Amount waiting collection⁠⁠⁠⁠">
                        <div class="md-card-content">
                            <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class="peity_sale peity_data">5,3,9,6,5,2</span></div>
                            <span class="uk-text-muted uk-text-small">Upcoming Revenue</span>
                            <h2 class="uk-margin-remove">£ <span class="countUpMe">0<noscript><?php $revenuea = 0; foreach($upcomingrevenue as $val){ $revenuea += $val['amount']; } echo $revenuea; ?></noscript></span></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
