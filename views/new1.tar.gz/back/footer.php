
</section>
<script src="<?= base_url('assets_f') ?>/js/slidebars.min.js"></script>
<script type="text/javascript" src="<?= base_url('assets_f') ?>/js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?= base_url('assets_f') ?>/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?= base_url('assets_f') ?>/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?= base_url('assets_f') ?>/js/jquery.scrollTo.min.js"></script>
<script src="<?= base_url('assets_f') ?>/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="<?= base_url('assets_f') ?>/js/respond.min.js"></script>
<script type="text/javascript" language="javascript" src="<?= base_url('assets_f') ?>/assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?= base_url('assets_f') ?>/assets/data-tables/DT_bootstrap.js"></script>
<script src="<?= base_url('assets_f') ?>/js/dynamic_table_init.js"></script>
<script src="<?= base_url('assets_f') ?>/js/common-scripts.js"></script>
<script>
    $(document).ready(function(){
        var table = $('#myTable').dataTable({
            "aaSorting": [[0,'desc']]
            //order: [[ 0, "asc" ]]
        });
        //table.column( 0 ).data().sort('asc');
        //table.order( [ 1, 'desc' ] ).draw();
    });
</script>

<script src="<?= base_url('assets_f/wysiwyg') ?>/dist/trumbowyg.js"></script>
<script src="<?= base_url('assets_f/wysiwyg') ?>/dist/langs/fr.min.js"></script>
<script src="<?= base_url('assets_f/wysiwyg') ?>/dist/plugins/base64/trumbowyg.base64.js"></script>
<script src="<?= base_url('assets_f/wysiwyg') ?>/dist/plugins/colors/trumbowyg.colors.js"></script>
<script src="<?= base_url('assets_f/wysiwyg') ?>/dist/plugins/noembed/trumbowyg.noembed.js"></script>
<script src="<?= base_url('assets_f/wysiwyg') ?>/dist/plugins/pasteimage/trumbowyg.pasteimage.js"></script>
<script src="<?= base_url('assets_f/wysiwyg') ?>/dist/plugins/preformatted/trumbowyg.preformatted.js"></script>
<script src="<?= base_url('assets_f/wysiwyg') ?>/dist/plugins/upload/trumbowyg.upload.js"></script>
<script>
    var uploadOptions = {
        serverPath: 'https://api.imgur.com/3/image',
        fileFieldName: 'image',
        headers: {'Authorization': 'Client-ID 9e57cb1c4791cea'},
        urlPropertyName: 'data.link'
    };

    $('#summernote').trumbowyg(
        {
            btns: [
                ['viewHTML'],
                ['p', 'blockquote', 'h1', 'h2', 'h3', 'h4'],
                ['strong', 'em', 'underline', 'del'],
                ['superscript', 'subscript'],
                ['createLink', 'unlink'],
                ['insertImage'],
                ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'],
                ['unorderedList', 'orderedList'],
                ['horizontalRule'],
                ['removeformat'],
                ['upload', 'noembed'],
                ['foreColor', 'backColor'],
                ['preformatted'],
                ['fullscreen']
            ],
            autogrow:true,
            plugins: {
                upload: uploadOptions
            }
        }
    );
</script>


<script src="<?= base_url('assets_f') ?>/chosen/chosen.jquery.js" type="text/javascript"></script>
<script src="<?= base_url('assets_f') ?>/chosen/docsupport/prism.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
    var config = {
        '.chosen-select'           : {placeholder:"Select Member"},
        '.chosen-select-deselect'  : {allow_single_deselect:true},
        '.chosen-select-no-single' : {disable_search_threshold:10},
        '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
        '.chosen-select-width'     : {width:"95%"}
    }
    $(".chosen-select").chosen();
</script>
</body>
</html>
