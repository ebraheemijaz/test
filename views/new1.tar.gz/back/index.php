<style>
    .value p{
        font-size: 13px;
    }
    .gap{
        padding: 10px;
    }
    @media (max-width:1000px){
        .visible-lg{
            margin-top:0 ;
        }
    }
    .task-progress, .task-progress > h1{
        color:#39b5aa !important;
        font-size:19px !important;
        font-weight:bold !important;
    }
</style>
<section id="main-content">
    <section class="wrapper ">
        <div class="row state-overview">
            <div class="col-lg-3 col-sm-3">
                <section class="panel">
                    <div style="background:#e67e22;" class="symbol terques">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="value">
                        <h1 class="count">
                            <?php $total = $gender['male'][0]['total'] + $gender['female'][0]['total'] ; ?>
                            <?= $gender['male'][0]['total'] ?>
                            :
                            <?= $gender['female'][0]['total'] ?>
                        </h1>
                        <p style="font-size:12px;font-weight: bold">Male  :  Female</p>
                        <p>Total : <?= $total; ?></p>
                    </div>
                </section>
            </div>
            <div class="col-lg-3 col-sm-3">
                <section class="panel">
                    <div style="background:#e74c3c;" class="symbol terques">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="value">
                        <h1 class="count">
                            <?= $age_group[0][0]['total'] ?>
                        </h1>
                        <p>Age Group</p><p> ( 0 - 9 )</p>
                    </div>
                </section>
            </div>
            <div class="col-lg-3 col-sm-3">
                <section class="panel">
                    <div style="background:#e74c3c;" class="symbol terques">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="value">
                        <h1 class="count">
                            <?= $age_group[1][0]['total'] ?>
                        </h1>
                        <p>Age Group </p><p> ( 10 - 18 )</p>
                    </div>
                </section>
            </div>
            <div class="col-lg-3 col-sm-3">
                <section class="panel">
                    <div style="background:#e74c3c;" class="symbol terques">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="value">
                        <h1 class="count">
                            <?= $age_group[2][0]['total'] ?>
                        </h1>
                        <p>Age Group </p><p> ( 19 - 29 )</p>
                    </div>
                </section>
            </div>
            <div class="col-lg-3 col-sm-3">
                <section class="panel">
                    <div style="background:#e74c3c;" class="symbol terques">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="value">
                        <h1 class="count">
                            <?= $age_group[3][0]['total'] ?>
                        </h1>
                        <p>Age Group </p><p> ( 30 - 39 )</p>
                    </div>
                </section>
            </div>
            <div class="col-lg-3 col-sm-3">
                <section class="panel">
                    <div style="background:#e74c3c;" class="symbol terques">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="value">
                        <h1 class="count">
                            <?= $age_group[4][0]['total'] ?>
                        </h1>
                        <p>Age Group </p><p> ( 40 - 49 )</p>
                    </div>
                </section>
            </div>
            <div class="col-lg-3 col-sm-3">
                <section class="panel">
                    <div style="background:#e74c3c;" class="symbol terques">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="value">
                        <h1 class="count">
                            <?= $age_group[5][0]['total'] ?>
                        </h1>
                        <p>Age Group </p><p> ( Above 50 )</p>
                    </div>
                </section>
            </div>
            <div class="col-lg-3 col-sm-3">
                <section class="panel">
                    <div style="background:#e74c3c;" class="symbol terques">
                        <i class="fa fa-user"></i>
                    </div>
                    <div class="value">
                        <h1 class="count">
                            £ <?= 0.00 . "/=" ?>
                        </h1>
                        <p>Account Balance</p>
                    </div>
                </section>
            </div>
        </div>
        <div class="row">

        </div>
            <div class="col-lg-7 col-md-7 visible-lg visible-md">
                <section class="panel">
                    <div class="panel-body progress-panel">
                        <div class="task-progress">
                            <h1>Calendar</h1>
                        </div>
                        <span style="float:right;font-weight:bold;color:#e74c3c">
                            S - Schedule Message
                            <br/>
                            V - View or Set Reminder
                        </span>
                    </div>
                    <div class="gap">
                        <table></table>
                        <div class="timeTable"></div>
                    </div>
                </section>
            </div>
            <div class="col-lg-5 col-md-5 visible-md visible-lg">
                <section class="panel">
<!--                    <header class="panel-heading">Clock</header>-->
                    <div class="panel-body progress-panel">
                        <div class="task-progress">
                            <h1>Clock</h1>
                        </div>
                        <br/>
                        <hr/>
                        <div style="border:none !important;" class="clock" id="clock"></div>
                        <div class="row"></div>
                        <p style="font-size:20px;text-align: center;font-weight: bold">
                            <?= date("D d-M-Y") ?>
                        </p>
                    </div>
                </section>
            </div>
            <div class="row"></div>
<!--        </div>-->
        <div class="row">
            <div class="col-md-12">
                <div class="col-md-6">
                    <section class="panel">
                        <div class="panel-body progress-panel">
                            <div class="task-progress">
                                <h1>Codes Generated</h1>
                            </div>
                        </div>
                        <div id="codesChart" width="400" height="200">

                        </div>
                        <!--<p style="text-align: center;font-weight: bold">
                            <span style="margin-right: 20px">Used: <?/*= $codesused[0]['total'] */?> </span>
                            <span>Unused: <?/*= $codesunused[0]['total'] */?></span>
                        </p>-->
                    </section>
                </div>
                <div class="col-md-6">
                    <section class="panel">
                        <div class="panel-body progress-panel">
                            <div class="task-progress">
                                <h1>Male/Female Ratio</h1>
                            </div>
                        </div>
                        <div id="myChart" width="400" height="200"></div>
                        <!--<p style="text-align: center;font-weight: bold">
                            <span style="margin-right: 20px">Male: <?/*= $gender['male'][0]['total'] */?></span>
                            <span>Female: <?/*= $gender['female'][0]['total'] */?></span>
                        </p>-->

                    </section>
                </div>
                <div class="col-md-6">
                    <section class="panel">
                        <div class="panel-body progress-panel">
                            <div class="task-progress">
                                <h1>Age Group Pie Chart Demograph</h1>
                            </div>
                        </div>
                        <div id="myChart2" width="400" height="200"></div>

                    </section>
                </div>
                <div class="col-md-6">
                    <section class="panel">
                        <div class="panel-body progress-panel">
                            <div class="task-progress">
                                <h1>Table Showing the Title Records</h1>
                            </div>
                        </div>
                        <table class="table table-hover">
                            <tr>
                                <th style="font-size:20px">Title</th>
                                <th style="font-size:20px">Total</th>
                            </tr>
                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Mr"){ $i+=1; } ?>
                            <?php } ?>
                            <tr>
                                <td>Mr</td>
                                <td><?= $i ?></td>
                            </tr>
                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Mrs"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Mrs</td>
                                    <td><?= $i ?></td>
                                </tr>
                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Miss"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Miss</td>
                                    <td><?= $i ?></td>
                                </tr>
                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Bishop"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Bishop</td>
                                    <td><?= $i ?></td>
                                </tr>

                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Pastor"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Pastor</td>
                                    <td><?= $i ?></td>
                                </tr>

                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Prophet"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Prophet</td>
                                    <td><?= $i ?></td>
                                </tr>

                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Prophetess"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Prophetess</td>
                                    <td><?= $i ?></td>
                                </tr>

                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Reverend"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Reverend</td>
                                    <td><?= $i ?></td>
                                </tr>

                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Deacon"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Deacon</td>
                                    <td><?= $i ?></td>
                                </tr>

                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Deaconess"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Deaconess</td>
                                    <td><?= $i ?></td>
                                </tr>

                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Dr"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Dr</td>
                                    <td><?= $i ?></td>
                                </tr>

                            <?php $i=0; foreach($members as $val){ ?>
                                <?php if($val['title'] == "Professor"){ $i+=1; } ?>
                            <?php } ?>
                                <tr>
                                    <td>Professor</td>
                                    <td><?= $i ?></td>
                                </tr>

                        </table>
                    </section>
                </div>
                <div class="row"></div>
                <div class="col-md-12">
                    <section class="panel">
                        <div class="panel-body progress-panel">
                            <div class="task-progress">
                                <h1>Monthly System Monitor</h1>
                            </div>
                        </div>
                        <div id="testChart" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
                    </section>
                </div>
                <div class="row"></div>
                <div class="col-md-12">
                    <section class="panel">
                        <div class="panel-body progress-panel">
                            <div class="task-progress">
                                <h1>Donations Graph</h1>
                            </div>
                        </div>
                        <div id="myChart4" width="400" height="200"></div>
                    </section>
                </div>
                <div class="row"></div>
                <div class="col-md-12">
                    <section class="panel">
                        <div class="panel-body progress-panel">
                            <div class="task-progress">
                                First Timer Graph
                            </div>
                        </div>
                        <div id="ftimer" width="400" height="100"></div>
                    </section>
                </div>
                <div class="row"></div>
                <div class="col-md-12 visible-lg visible-md">
                    <section class="panel">
                        <div class="panel-body progress-panel">
                            <div class="task-progress">
                                <h1>Member's Country of origin chart</h1>
                            </div>
                        </div>
                        <canvas id="myChart5" width="400" height="100"></canvas>
                    </section>
                </div>

                <div class="row"></div>
                <div class="">
                    <div class="col-md-6">
                        <section class="panel">
                            <div class="panel-body progress-panel">
                                <div class="task-progress">
                                    <h1>Members Activity</h1>
                                </div>
                            </div>
                            <table id="myTable" class="table table-hover">
                                <tr>
                                    <td>Member</td>
                                    <td>Status</td>
                                    <td>Last Activity</td>
                                </tr>
                                <tbody id="usrActivity">

                                </tbody>
                            </table>
                            <div class="row"></div>
                        </section>
                    </div>
                    <div class="col-md-6">
                        <section class="panel">
                            <div class="panel-body progress-panel">
                                <div class="task-progress">
                                    <h1>Notifications</h1>
                                </div>
                            </div>
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <td>ID</td>
                                    <td>Notification</td>
                                    <td>View</td>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach($businessGroupnew as $k=>$val){ ?>
                                    <tr>
                                        <td><?= $k+1; ?></td>
                                        <td>A member added a new Business group <?= $val['name'] ?></td>
                                        <td><a href="<?= site_url('admin/view/edit_group/'.$val['id']."/businessGroup") ?>">Edit</a></td>
                                    </tr>
                                <?php } ?>
                                <?php foreach($churchgroupnew as $k=>$val){ ?>
                                    <tr>
                                        <td><?= $k+1; ?></td>
                                        <td>A member added a new Church group <?= $val['name'] ?></td>
                                        <td><a href="<?= site_url('admin/view/edit_group/'.$val['id']."/churchgroup") ?>">Edit</a></td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                            <div class="row"></div>
                        </section>
                    </div>
                </div>
            </div>
        </div>

    </section>
</section>
<script>
    $.post("<?= site_url('admin/calender') ?>",{},function(e){
        $(".timeTable").html(e);
    });
    setInterval(function(){
        $.post("<?= site_url('admin/ajax/getUsers') ?>",{},function(e){
            $("#usrActivity").html(e);
        })
    },2000);

</script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>

<script>
    //testChart
    var colors = Highcharts.getOptions().colors;

    //ftimer
    $(function () {
        Highcharts.chart('ftimer', {
            chart: {
                type: 'column'
            },
            colors:["#0F3057"],
            title: {
                text: ''
            },
            subtitle: {
                text: 'Source: <a href="http://mmsonline.website">//mmsonline.website</a>'
            },
            xAxis: {
                type: 'category',
                labels: {
                    rotation: 0,
                    style: {
                        fontSize: '13px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                }
            },
            yAxis: {
                min: 0,
                title: {
                    text: 'Registration (First timer)'
                }
            },
            legend: {
                enabled: false
            },
            tooltip: {
                pointFormat: 'Registration count: <b>{point.y:.f}</b>'
            },
            series: [{
                name: 'Registration',
                data: [
                    ['Jan', 23],
                    ['Feb', 16],
                    ['Mar', 14],
                    ['Apr', 14],
                    ['May', 12],
                    ['Jun', 12],
                    ['Jul', 11],
                    ['Aug', 11],
                    ['Sep', 11],
                    ['Oct', 11],
                    ['Nov', 10],
                    ['Dec', 10]
                ],
                dataLabels: {
                    enabled: true,
                    rotation: -90,
                    color: '#FFFFFF',
                    align: 'right',
                    y: 10, // 10 pixels down from the top
                    style: {
                        fontSize: '13px',
                        fontFamily: 'Verdana, sans-serif'
                    }
                }
            }]
        });
    });
    $(function () {
        Highcharts.chart('testChart', {
            chart: {
                zoomType: 'xy'
            },
            title: {
                text: ''
            },
            colors:["#1DABB8","#000"],
            subtitle: {
                text: 'Source: //mmsonline.website'
            },
            xAxis: [{
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                crosshair: true
            }],
            yAxis: [
                {
                labels: {
                    format: '{value}',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                },
                title: {
                    text: 'Registration',
                    style: {
                        color: Highcharts.getOptions().colors[1]
                    }
                }
            },
                {
                title: {
                    text: 'Logged in',
                    style: {
                        color: Highcharts.getOptions().colors[0]
                    }
                },
                labels: {
                    format: '{value}',
                    style: {
                        color: Highcharts.getOptions().colors[0]
                    }
                },
                opposite: true
            }],
            tooltip: {
                shared: true
            },
            legend: {
                layout: 'vertical',
                align: 'left',
                x: 120,
                verticalAlign: 'top',
                y: 100,
                floating: true,
                backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
            },
            series: [{
                name: 'New Registrations',
                type: 'column',
                yAxis: 1,
                data: [10,2,10,6,7,5,9,5,2,6,3,10],
                tooltip: {
                    valueSuffix: ''
                }

            }, {
                name: 'Login count',
                type: 'spline',
                data: [12, 2, 10, 14, 18, 21, 25, 26, 23, 18, 13, 19],
                tooltip: {
                    valueSuffix: ''
                }
            }]
        });
    });
    $(function () {
        Highcharts.chart('myChart2', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text:''
            },
            colors:["#E3000E","#3D8EB9","#F04903","#1DABB8"],
            tooltip: {
                pointFormat: '{series.name}: <b>{point.y:f} ({point.percentage:.1f}%)</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        useHTML: true,
                        formatter: function () {
                            var point = this.point,
                                width = 50,
                                height = 50,
                                series = point.series,
                                center = series.center,               //center of the pie
                                startX = point.labelPos[4],           //connector X starts here
                                endX = point.labelPos[0] + 5,         //connector X ends here
                                left =  -(endX - startX + width / 2), //center label over right edge
                                startY = point.labelPos[5],           //connector Y starts here
                                endY = point.labelPos[1] - 5,         //connector Y ends here
                                top =  -(endY - startY + height / 2); //center label over right edge


                            // now move inside the slice:
                            left += (center[0] - startX)/2;
                            top += (center[1] - startY)/2;

                            if (point.id == 'razr') {
                                console.log(this);
                                return '<div><b>' + point.y + '</b></div><div style="width: ' + width + 'px; left:' + left + 'px;top:' + top + 'px; text-align: center; position: absolute"><b>sum is:<br/>' + point.summ + ' </b></div>';
                            } else return '<b>' + point.y + '<b>';
                        }
                    },
                    showInLegend: true
                }
            },
            series: [{
                name: 'Ratio',
                colorByPoint: true,
                data: [{
                    name: '0 - 9',
                    y: <?= $age_group[0][0]['total'] ?>,
                    color:colors[1]
                }, {
                    name: '10 - 18',
                    y: <?= $age_group[1][0]['total'] ?>,
                    color:colors[2]
                }, {
                    name: '19 - 29',
                    y: <?= $age_group[2][0]['total'] ?>,
                    color: colors[3]
                }, {
                    name: '30 - 39',
                    y: <?= $age_group[3][0]['total'] ?>,
                    color:colors[4]
                }, {
                    name: '40 - 49',
                    y: <?= $age_group[4][0]['total'] ?>,
                    color:colors[5]
                }, {
                    name: 'Above 50',
                    y: <?= $age_group[5][0]['total'] ?>,
                    color:colors[6]
                }
                ]
            }]
        });
    });
    $(function () {
        // Radialize the colors
//        Highcharts.getOptions().colors = Highcharts.map(Highcharts.getOptions().colors, function (color) {
//            return {
//                radialGradient: {
//                    cx: 0.5,
//                    cy: 0.3,
//                    r: 0.7
//                },
//                stops: [
//                    [0, color],
//                    [1, Highcharts.Color(color).brighten(-0.3).get('rgb')] // darken
//                ]
//            };
//        });
        Highcharts.chart('myChart', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },

            title: {
                text: ''
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.y:f} ({point.percentage:.1f}%)</b>'
            },
            plotOptions: {
                pie: {
                    showInLegend: true,
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        useHTML: true,
                        formatter: function () {
                            var point = this.point,
                                width = 50,
                                height = 50,
                                series = point.series,
                                center = series.center,               //center of the pie
                                startX = point.labelPos[4],           //connector X starts here
                                endX = point.labelPos[0] + 5,         //connector X ends here
                                left =  -(endX - startX + width / 2), //center label over right edge
                                startY = point.labelPos[5],           //connector Y starts here
                                endY = point.labelPos[1] - 5,         //connector Y ends here
                                top =  -(endY - startY + height / 2); //center label over right edge


                            // now move inside the slice:
                            left += (center[0] - startX)/2;
                            top += (center[1] - startY)/2;

                            if (point.id == 'razr') {
                                console.log(this);
                                return '<div><b>' + point.y + '</b></div><div style="width: ' + width + 'px; left:' + left + 'px;top:' + top + 'px; text-align: center; position: absolute"><b>sum is:<br/>' + point.summ + ' </b></div>';
                            } else return '<b>' + point.y + '<b>';
                        }
                    }
                }
            },
            series: [{
                name: 'Ratio',
                data: [
                    {name: 'Male', y: <?= $gender['male'][0]['total'] ?>,color:colors[2]},
                    {name: 'Female', y: <?= $gender['female'][0]['total'] ?>,color:colors[8]}
                ]
            }]
        });
        Highcharts.chart('codesChart', {
            chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie'
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: '{series.name}: <b>{point.y:f} ({point.percentage:.1f}%)</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        useHTML: true,
                        formatter: function () {
                            var point = this.point,
                                width = 50,
                                height = 50,
                                series = point.series,
                                center = series.center,               //center of the pie
                                startX = point.labelPos[4],           //connector X starts here
                                endX = point.labelPos[0] + 5,         //connector X ends here
                                left =  -(endX - startX + width / 2), //center label over right edge
                                startY = point.labelPos[5],           //connector Y starts here
                                endY = point.labelPos[1] - 5,         //connector Y ends here
                                top =  -(endY - startY + height / 2); //center label over right edge


                            // now move inside the slice:
                            left += (center[0] - startX)/2;
                            top += (center[1] - startY)/2;

                            if (point.id == 'razr') {
                                console.log(this);
                                return '<div><b>' + point.y + '</b></div><div style="width: ' + width + 'px; left:' + left + 'px;top:' + top + 'px; text-align: center; position: absolute"><b>sum is:<br/>' + point.summ + ' </b></div>';
                            } else return '<b>' + point.y + '<b>';
                        }
                    },
                    showInLegend:true
                }
            },
            series: [{
                name: 'Ratio',
                data: [
                    {
                        name: 'Used', y: <?= $codesused[0]['total'] ?>,
                        color:"#00c558"
                    },
                    {
                        name: 'Unused', y: <?= $codesunused[0]['total'] ?>,
                        //color:"#00a1c5"
                        color:{radialGradient: { cx: 0.1, cy: 0.9, r: 0.5 },
                            stops: [
                                [0, '#003399'],
                                [1, '#3366AA']
                            ]}
                    }
                ]
            }]
        });
    });
    $(function () {
        Highcharts.chart('myChart4', {
            chart: {
                type: 'area'
            },
            colors: ['#2ecc71'],
            title: {
                text: ''
            },
            subtitle: {
                text: 'Source: <a href="http://mmsonline.website">' +
                '//mmsonline.website</a>'
            },
            xAxis: {
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                allowDecimals: false
//                ,
//                labels: {
//                    formatter: function () {
//                        return this.value; // clean, unformatted number for year
//                    }
//                }
            },
            yAxis: {
                title: {
                    text: 'Total Donations State'
                },
                labels: {
                    formatter: function () {
                        return this.value / 1000 + 'k';
                    }
                }
            },
            tooltip: {
                pointFormat: '{series.name} produced : <b>{point.y:,.0f}</b>'
            },
            plotOptions: {
                area: {
                    //pointStart: <//?= date("Y")?>,
                    marker: {
                        enabled: false,
                        symbol: 'circle',
                        radius: 2,
                        states: {
                            hover: {
                                enabled: true
                            }
                        }
                    }
                }
            },
            series: [
                {
                    name: 'Donations',
                    data: [
                        <?php for($i=0;$i<12;$i++){ ?>
                        <?= ($dMonths[$i][0]['amount'] == NULL) ? "null" : $dMonths[$i][0]['amount']; ?><?= ($i<=11) ? "," : "" ; ?>
                        <?php } ?>
                    ]
                }
            ]
        });
    });
    $(document).ready(function(){
       $(".highcharts-credits").css("display","none");
    });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.6/Chart.bundle.min.js"></script>
<script>
    var ctx = document.getElementById("myChart5");
    var data = {
        labels: [
            <?php $i=1; foreach($countryOrigin as $k=>$v){ ?>
                "<?php echo $v['nativeCountry'] ?>"
                <?php if($i < count($countryOrigin)){ echo ","; } ?>
            <?php $i++; } ?>
        ],
        datasets: [{
            label: "",
            backgroundColor: "#6dbb4a",
            borderWidth: 1,
            hoverBackgroundColor: "#6dbb4a",
            data: [
                <?php $i=1; foreach($countryOrigin as $k=>$v){ ?>
                    <?php echo $v['total'] ?>
                    <?php if($i < count($countryOrigin)){ echo ","; } ?>
                <?php $i++; } ?>
            ]
        }]
    };
    var myBarChart = new Chart(ctx, {
        type: 'horizontalBar',
        data: data,
        options: {scales: {xAxes: [{stacked: true}], yAxes: [{stacked: true}]}}
    });

    var ctx = document.getElementById("ftimer");
    var data = {
        labels: [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"
        ],
        datasets: [{
            label: "",
            backgroundColor: "rgba(54,162,235,0.7)",
            borderColor: "rgba(54,162,235,0.7)",
            borderWidth: 1,
            hoverBackgroundColor: "rgba(54,162,235,1)",
            hoverBorderColor: "rgba(54,162,235,0.7)",
            data: [
                1,2,1,3,2,2,1,3,1,4,2,1
            ]
        }]
    };
    var myBarChart = new Chart(ctx, {
        type: 'bar',
        data: data,
        options: {scales: {xAxes: [{stacked: true}], yAxes: [{stacked: true}]}}
    });
</script>
<link rel="stylesheet" href="<?= base_url('assets_b/clock/example') ?>/css/demo.css"/>
<script type="text/javascript" src="<?= base_url('assets_b/clock/example') ?>/js/clock-1.1.0.min.js"></script>
<script>
    var clock1 = $("#clock").clock({
        theme: 't3'
    });
</script>