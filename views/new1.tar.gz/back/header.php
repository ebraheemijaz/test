<?php
//var_dump($userAdmin[0]['access']);die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Jetnetix">
    <meta name="keyword" content="Tutor Management System">
    <link rel="shortcut icon" href="<?= base_url('assets_f') ?>/logo.png">
    <title>Admin @ Membership Management System- Login</title>
    <link href="<?= base_url('assets_f') ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= base_url('assets_f') ?>/css/bootstrap-reset.css" rel="stylesheet">
    <link href="<?= base_url('assets_f') ?>/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="<?= base_url('assets_f') ?>/assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
    <link rel="stylesheet" href="<?= base_url('assets_f') ?>/css/owl.carousel.css" type="text/css">
    <link href="<?= base_url('assets_f') ?>/css/tasks.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets_f') ?>/assets/fuelux/css/tree-style.css" />
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets_f') ?>/assets/jquery-multi-select/css/multi-select.css" />
    <link href="<?= base_url('assets_f') ?>/assets/morris.js-0.4.3/morris.css" rel="stylesheet" />
    <link href="<?= base_url('assets_f') ?>/assets/fullcalendar/fullcalendar/bootstrap-fullcalendar.css" rel="stylesheet" />
    <link href="<?= base_url('assets_f') ?>/assets/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
    <link href="<?= base_url('assets_f') ?>/assets/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?= base_url('assets_f') ?>/assets/data-tables/DT_bootstrap.css" />
    <link href="<?= base_url('assets_f') ?>/css/slidebars.css" rel="stylesheet">
    <link href="<?= base_url('assets_f') ?>/css/style.css" rel="stylesheet">
    <link href="<?= base_url('assets_f') ?>/css/style-responsive.css" rel="stylesheet" />
    <script src="<?= base_url('assets_f') ?>/js/jquery.js"></script>
<!--    <script src="--><?//= base_url('assets_f') ?><!--/js/bootstrap.min.js"></script>-->
<!--    <script src="js/bootstrap.min.js"></script>-->
    <link rel="stylesheet" href="<?= base_url('assets_f/wysiwyg') ?>/dist/ui/trumbowyg.css">
    <link rel="stylesheet" href="<?= base_url('assets_f/wysiwyg') ?>/dist/plugins/colors/ui/trumbowyg.colors.css">
    <!-- Include the plugin's CSS and JS: -->
    <script type="text/javascript" src="<?= base_url('assets_f') ?>/multiselect/bootstrap-multiselect.js"></script>
    <link rel="stylesheet" href="<?= base_url('assets_f') ?>/multiselect/bootstrap-multiselect.css" type="text/css"/>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tool tips and media queries -->
    <!--[if lt IE 9]>
    <script src="<?= base_url('assets_f') ?>/js/html5shiv.js"></script>
    <script src="<?= base_url('assets_f') ?>/js/respond.min.js"></script>
    <![endif]-->
    <Style>
        .form-horizontal .control-label {
            color: #000;
        }
        @media print {
            body * {
                /*visibility: hidden;*/
            }
            #section-to-print, #section-to-print * {
                /*visibility: visible;*/
            }
            #section-to-print {
                /*position: absolute;*/
                /*left: 0;*/
                /*top: 0;*/
            }
        }
        @media(min-width:992px) AND (max-width:1199px) {
            .visible-md {
                display: inline-block !important;
            }
        }
        @media(min-width:1200px){
            .visible-lg {
                display: inline-block !important;
            }
        }
        .panel-heading{
            font-size:20px;
            font-weight: bold;
        }
        thead>tr>td{
            font-size:16px;
            font-weight: bold;
        }
        .form-signin{
            margin-top:0px !important;
        }
        .form-signin > p{
            /*font-weight: bold;*/
            text-align:left !important;
            color:black;
        }
    </Style>
    <script type="text/javascript">
        var idleTime = 0;
        $(document).ready(function () {
            var idleInterval = setInterval(timerIncrement, 60000);
            $(this).mousemove(function(e){
                idleTime = 0;
            });
            $(this).keypress(function(e){
                idleTime = 0;
            });
        });
        function timerIncrement() {
            idleTime = idleTime + 1;
            if (idleTime > 59) {
                window.location.href = "<?= site_url('admin/logout'); ?>";
            }
        }
    </script>
<!--    <link rel="stylesheet" href="--><?//= base_url('assets_f') ?><!--/chosen/docsupport/style.css">-->
<!--    <link rel="stylesheet" href="--><?//= base_url('assets_f') ?><!--/chosen/docsupport/prism.css">-->
    <link rel="stylesheet" href="<?= base_url('assets_f') ?>/chosen/chosen.css">
</head>

<body>

<section id="container" >
    <!--header start-->
    <header class="header white-bg">
        <div class="sidebar-toggle-box">
            <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
        </div>
        <!--logo start-->
        <a href="" style="color:grey !important;" class="logo">
            <img src="<?= base_url('assets_f') ?>/logo.png" style="width:30px;" alt=""/>
            M<span class="visible-lg visible-md">embership  </span>
            M<span class="visible-lg visible-md">anagement  </span>
            S<span class="visible-lg visible-md">YSTEM      </span>
        </a>
        <div class="nav notify-row" id="top_menu">
            <!--  notification start -->
            <ul class="nav top-menu">

            </ul>
        </div>
        <div class="top-nav ">
            <ul class="nav pull-right top-menu">
                <li class="dropdown">
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                        <span class="username"><?= $userAdmin[0]['name'] ?></span>
                        <b class="caret"></b>
                    </a>
                    <ul class="dropdown-menu extended logout">
                        <div class="log-arrow-up"></div>
                        <li><a href="<?= site_url('admin/view/acc_settings') ?>"><i class="fa fa-gear"></i> Account Setting</a></li>
                        <li><a href="<?= site_url('admin/logout') ?>"><i class="fa fa-key"></i> Log Out</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </header>
    <aside>
        <div id="sidebar"  class="nav-collapse ">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="<?= site_url('admin/view') ?>/index.php">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="<?= site_url('admin/view') ?>/live">
                        <i class="fa fa-video-camera"></i>
                        <span>Live</span>
                    </a>
                </li>
                <li class="sub-menu">
                    <a href="#">
                        <i class="fa fa-book"></i>
                        <span>Book Store</span>
                    </a>
                    <ul class="sub">
                        <li>
                            <a href="<?= site_url('admin/view') ?>/bookstore">
                                <span>Books</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?= site_url('admin/view') ?>/add_book">
                                <span>Add Book</span>
                            </a>
                        </li>
                    </ul>
                </li>

                <?php $access = ($userAdmin[0]['access'] != NULL) ? $userAdmin[0]['access'] : "admin";  ?>
                <?php if($access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-key"></i>
                            <span>Codes</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/create_code">Generate Codes</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/manage_codes">Manage Codes</a></li>
                        </ul>
                    </li>
                <?php } ?>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-edit"></i>
                        <span>Bulletin</span>
                    </a>
                    <ul class="sub">
                        <li><a href="<?= site_url('admin/view') ?>/create_bulletin">Create Bulletin</a></li>
                        <li><a href="<?= site_url('admin/view') ?>/view_bulletin">Manage Bulletin</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-list-alt"></i>
                        <span>Advert</span>
                    </a>
                    <ul class="sub">
                        <li><a href="<?= site_url('admin/view') ?>/advert">Manage Advert</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-list"></i>
                        <span>Attendance</span>
                    </a>
                    <ul class="sub">
                        <li><a href="<?= site_url('admin/view') ?>/attendance">Manage Attendance</a></li>
                    </ul>
                </li>
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-check"></i>
                        <span>Reports</span>
                    </a>
                    <ul class="sub">
                        <li><a href="<?= site_url('admin/view') ?>/view_report">Generate Report</a></li>
                    </ul>
                </li>
                <?php if(isset($access['members']) OR $access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-group"></i>
                            <span>Member</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/manage_users">Manage Users</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/create_users">Create Users</a></li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-group"></i>
                            <span>First Timer</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/manage_ftimer">Manage First Timer</a></li>
                        </ul>
                    </li>
                <?php } ?>
                <?php if($access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-user"></i>
                            <span>Manage Admin</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/manage_admin">View Manager</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/create_admin">Create Manager</a></li>
                        </ul>
                    </li>
                <?php } ?>

                <?php if(isset($access['donations']) OR $access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-gbp"></i>
                            <span>Collections</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/manage_donations">Donations</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/view_offerings">Offering Collections</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/view_tithes">Tithes Received</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/view_gave_life">Life To Christ</a></li>

                        </ul>
                    </li>
                <?php } ?>

                <?php if(isset($access['updates']) OR $access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-pencil"></i>
                            <span>The Word</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/prepare_word">Upload Word</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/view_word">View Word</a></li>
                        </ul>
                    </li>
                <?php } ?>
                <?php if(isset($access['reviews']) OR $access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-calendar"></i>
                            <span>Review</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/manage_reviews">Manage Reviews</a></li>
                        </ul>
                    </li>
                <?php } ?>


                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-envelope"></i>
                            <span>Message</span>
                        </a>
                        <ul class="sub">
                            <?php if(isset($access['messages']) OR $access == 'admin'){ ?>
                                <li><a href="<?= site_url('admin/view') ?>/chat_member">Start Chat w/ Member</a></li>
                            <?php } ?>
                            <li><a href="<?= site_url('admin/view') ?>/chat_admin">Start Chat w/ Admin</a></li>
                        </ul>
                    </li>


                <?php if(isset($access['groups']) OR $access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-group"></i>
                            <span>Group</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/manage_cGroups">Manage Church Group</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/manage_bGroups">Manage Business Group</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/add_group">Add</a></li>
                        </ul>
                    </li>
                <?php } ?>

                <?php if(isset($access['pastors']) OR $access == 'admin'){ ?>
                    <li>
                        <a href="<?= site_url('admin/view') ?>/pastors_diary">
                            <i class="fa fa-book"></i>
                            <span>Pastors Diary</span>
                        </a>
                    </li>
                <?php } ?>

                <?php if(isset($access['notifications']) OR $access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-bell"></i>
                            <span>Notifications</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/prayerRequest">Prayer Requests</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/testimonies">Testimonies</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/manage_users">Group Activities</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/new_signups">New Sign Ups</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/birthdays">Birthdays</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/page_verifications">Page Verifications</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/businessOffers">Business Offers</a></li>
                            <!--<li><a href="--><?//= site_url('admin/view') ?><!--/manage_invoices">Members Invoices</a></li>-->
                        </ul>
                    </li>
                <?php } ?>

                <?php if($access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-paper-plane"></i>
                            <span>Send SMS</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view/send_sms') ?>">Send By Number</a></li>
                            <li><a href="<?= site_url('admin/view/send_sms_member') ?>">Send To Member</a></li>
                            <li class="sub-menu">
                                <a href="javascript:;">Send By Group</a>
                                <ul class="sub">
                                    <li><a href="<?= site_url('admin/view/send_sms_church') ?>">Send By Church Group</a></li>
                                    <li><a href="<?= site_url('admin/view/send_sms_business') ?>">Send By Business Group</a></li>
                                </ul>
                            </li>
                            <li><a href="<?= site_url('admin/view/manage_sms') ?>">History</a></li>
                            <li><a href="<?= site_url('admin/') ?>/#">Top Up SMS Account</a></li>
                        </ul>
                    </li>
                <?php } ?>

                <?php if(isset($access['settings']) OR $access == 'admin'){ ?>
                    <li class="sub-menu">
                        <a href="javascript:;">
                            <i class="fa fa-wrench"></i>
                            <span>Settings</span>
                        </a>
                        <ul class="sub">
                            <li><a href="<?= site_url('admin/view') ?>/settings">General Settings</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/msgsettings">Email Settings</a></li>
                            <li><a href="<?= site_url('admin/view') ?>/respsettings">Responder Settings</a></li>
                        </ul>
                    </li>
                <?php } ?>

            </ul>
        </div>
    </aside>