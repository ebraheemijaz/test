<div id="page_content">
    <div id="page_content_inner">
        <h4 class="heading_a uk-margin-bottom">Book Store</h4>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-medium-8-10">
                <div class="uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 hierarchical_show" data-uk-grid="{gutter: 20, controls: '#products_sort'}">
                    <?php $i=1; foreach($books as $val){ ?>
                        <div data-product-name="<?= $val['title'] ?>">
                            <div class="md-card md-card-hover-img">
                                <div class="md-card-head uk-text-center uk-position-relative">
<!--                                    <div class="uk-badge uk-badge-danger uk-position-absolute uk-position-top-left uk-margin-left uk-margin-top">$ 555.00</div>-->
                                    <img class="md-card-head-img" src="<?= base_url('assets_f/img') ?>/<?= $val['image'] ?>" alt=""/>
                                </div>
                                <div class="md-card-content">
                                    <h4 class="heading_c uk-margin-bottom">
                                        <?= $val['title'] ?>
                                    </h4>
                                    <p><?= substr($val['desc'],0,100) ?>...</p>
                                    <a class="md-btn md-btn-success" href="<?= site_url('home/getBook')."/".$val['id'] ?>">Get</a>
                                </div>
                            </div>
                        </div>
                        <?php $i++; } ?>
                </div>
            </div>
            <?php require_once('advert_v.php') ?>
        </div>
    </div>
</div>

