<div id="page_content">
    <div id="page_content_inner">
        <h3 class="heading_b uk-margin-bottom">Testimonies</h3>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-medium-8-10">
                <div class="md-card uk-margin-medium-bottom">
                    <div class="md-card-content">
                        <div class="dt_colVis_buttons">
                            <button class="md-btn md-btn-danger" data-uk-modal="{target:'#newModal'}">Share New</button>
                        </div>
                        <table id="dt_Export" class="uk-table" cellspacing="0" width="100%">
                            <tr>
                                <td>#</td>
                                <td>Subject</td>
                                <td>Message</td>
                                <td>Anonymous?</td>
                                <td style="width: 90px">Date</td>
                            </tr>
                            <?php $i=1; foreach($testimonies as $val){ ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?= $val['subject'] ?></td>
                                    <td style="word-break: break-all;">
                                        <?= substr($val['msg'],0,100); ?>
                                        <a href="#my-id<?= $val['id'] ?>" data-uk-modal><span class="md-btn-primary">Read More</span></a>
                                    </td>
                                    <td><?= ($val['anon'] == "true") ? "Yes" : "No"; ?></td>
                                    <td><?= date("d-M-Y",strtotime($val['date'])) ?></td>
                                </tr>

                                <div id="my-id<?= $val['id'] ?>" class="uk-modal">
                                    <div class="uk-modal-dialog">
                                        <a href="" class="uk-modal-close uk-close"></a>
                                        <h1><?= $val['subject'] ?></h1>
                                        <p style="word-break: break-all">
                                            <?= $val['msg'] ?>
                                        </p>
                                    </div>
                                </div>


                                <?php $i++; } ?>
                        </table>
                    </div>
                </div>

            </div>
            <?php require_once('advert_v.php'); ?>

        </div>
    </div>
</div>

<div id="newModal" class="uk-modal">
    <div class="uk-modal-dialog">
        <a href="" class="uk-modal-close uk-close"></a>
        <h1>Testimonies</h1>
        <?= form_open("home/insert/testimonies/testimonies?id=1",array('class'=>"form-horizontal")) ?>
        <div class="uk-form-row">
            <div class="uk-width-medium-1-1">
                <label>Subject</label>
                <input type="text" name="subject" class="md-input" />
            </div>
        </div>
        <div class="uk-form-row">
            <div class="uk-width-medium-1-1">
                <input type="checkbox" data-md-icheck name="anon" value="true"> Treat as Anonymous:
            </div>
        </div>
        <div class="uk-form-row">
            <div class="uk-width-medium-1-1">
                <label>Description</label>
                <textarea id="" cols="30" rows="4" name="msg" class="md-input"></textarea>
            </div>
            <span id="textLe">0</span>/500
        </div>
        <div class="uk-form-row">
            <input type="submit" class="md-btn md-btn-success" value="Send Now!"/>
        </div>
        </form>
    </div>
</div>
<script>
    $("[name=msg]").keyup(function(){
        var a = $("[name=msg]").val();
        $("[name=msg]").val(a.substring(0,500));
        lenght = a.length;
        $("#textLe").html(lenght);
    });
</script>
<script>
    <?php if(isset($_GET['received'])){ ?>
        setTimeout(function(){
            UIkit.notify({
                message : 'Testimony Received with Thanks – Your testimony shall be permanent',
                status  : 'danger',
                timeout : 2000,
                pos     : 'top-center'
            });
        },1000);
    <?php } ?>
</script>
