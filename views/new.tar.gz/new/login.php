<!doctype html>
<!--[if lte IE 9]> <html class="lte-ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="en"> <!--<![endif]-->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="google-signin-client_id" content="667428527963-u21s5caeb2ja69ej723ajc652lrfaev0.apps.googleusercontent.com">

    <!-- Remove Tap Highlight on Windows Phone IE -->
    <meta name="msapplication-tap-highlight" content="no"/>
    <link rel="icon" type="image/png" href="<?= base_url('assets_f/logo.png') ?>" sizes="16x16">
    <link rel="icon" type="image/png" href="<?= base_url('assets_f/logo.png') ?>" sizes="32x32">
    <title>Membership Management System - Login</title>
    <link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500' rel='stylesheet' type='text/css'>
    <!-- uikit -->
    <link rel="stylesheet" href="<?= base_url('assets_new') ?>/bower_components/uikit/css/uikit.almost-flat.min.css"/>
    <!-- altair admin login page -->
    <link rel="stylesheet" href="<?= base_url('assets_new') ?>/assets/css/login_page.min.css" />
</head>
<body class="login_page">
    <div class="login_page_wrapper">
        <div class="md-card" id="login_card">
            <div class="md-card-content large-padding" id="login_form">
                <div class="login_heading">
                    <div class="user_avatar" style="width:160px;height:160px;background-image: url(<?= base_url('assets_f/logo.png') ?>);background-size: 100% 100%">
                    </div>
                </div>
                <?= form_open("home/dologin",array("autocomplete"=>"off")) ?>
                    <div class="uk-form-row">
                        <label for="login_username">Username</label>
                        <input class="md-input" type="text" id="login_username" autocomplete="off" name="email" />
                    </div>
                    <div class="uk-form-row">
                        <label for="login_password">Password</label>
                        <input class="md-input" type="text" id="login_password" name="password" />
                        <p id="errorrrr" style="text-align:center;"><?php if(!empty($msg)){ ?><?= $msg; ?><?php } ?></p>
                    </div>
                    <div class="uk-margin-medium-top">
                        <span class="icheck-inline">
                            <input type="checkbox" id="login_page_stay_signed" data-md-icheck />
                            <label for="login_page_stay_signed" class="inline-label">Stay signed in</label>
                        </span>

                        <button class="md-btn md-btn-primary md-btn-block md-btn-large">Sign In</button>
                    </div>
                    <div class="uk-grid uk-grid-width-1-2 uk-grid-small uk-margin-top">

                        <div><a href="#" onclick="testAPI();" class="md-btn md-btn-block md-btn-facebook" data-uk-tooltip="{pos:'bottom'}" title="Sign in with Facebook"><i class="uk-icon-facebook uk-margin-remove"></i></a></div>
                        <div>
                            <div onclick="gS();" class="md-btn md-btn-block md-btn-gplus" data-onsuccess="onSignIn" data-uk-tooltip="{pos:'bottom'}" title="Sign in with Google+"><i class="uk-icon-google-plus uk-margin-remove"></i></div>
                            <div style="display:none;" data-onsuccess="onSignIn" class="g-signin2"></div>
                            <script>
                                function gS(){
                                    $(".abcRioButtonContentWrapper").click();
                                }
                            </script>
                        </div>
                    </div>
                    <div class="uk-margin-top">
                        <a href="#" id="login_help_show" class="uk-float-right">Need help?</a>
                        <span class="icheck-inline">
                        <a href="<?= base_url(); ?>/TERMS AND CONDITIONS FOR THE  APPLICATION.pdf" target="_blank" class="uk-float-right">Terms</a>


                        </span>
                    </div>
                <?= form_close() ?>
            </div>
            <div class="md-card-content large-padding uk-position-relative" id="login_help" style="display: none">
                <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
                <h2 class="heading_b uk-text-success">Can't log in?</h2>
                <p>Here’s the info to get you back in to your account as quickly as possible.</p>
                <p>First, try the easiest thing: if you remember your password but it isn’t working, make sure that Caps Lock is turned off, and that your username is spelled correctly, and then try again.</p>
                <p>If your password still isn’t working, it’s time to <a href="#" id="password_reset_show">reset your password</a>.</p>
                <p>To become a member, ensure you have obtained a valid code from your church administration office to <a id="signup_form_show" href="#">create an account</a>.</p>
            </div>
            <div class="md-card-content large-padding" id="login_password_reset" style="display: none">
                <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
                <h2 class="heading_a uk-margin-large-bottom">Reset password</h2>
                <?= form_open('home/forgotPwd'); ?>
                    <div class="uk-form-row">
                        <label for="login_email_reset">Your email address</label>
                        <input class="md-input" type="text" id="login_email_reset" name="email" />
                        <p style="text-align: center;display:none;" id="errorForget">Email Sent</p>
                    </div>
                    <div class="uk-margin-medium-top">
                        <button type="button" onclick="forgotPwd()" class="md-btn md-btn-primary md-btn-block">Reset password</button>
                    </div>
                </form>
            </div>
            <div class="md-card-content large-padding" id="register_form" style="display: none">
                <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
                <h2 class="heading_a uk-margin-medium-bottom">Create an account</h2>
                <?= form_open_multipart('home/doRegister') ?>
                    <div class="uk-form-row" id="codeFieldDiv">
                        <label for="register_username">Enter Code</label>
                        <input class="md-input" type="text" id="codec" name="code" />
                        <p id="errorCode" style="text-align: center"></p>
                        <button type="button" onclick="validateCode()" id="val" class="md-btn md-btn-info">Validate</button>
                    </div>
                    <div id="regField" style="display: none;">
                        <div class="uk-grid uk-grid-width-1-2 uk-grid-small uk-margin-top">
                            <div><a href="#" onclick="testAPIreg();" class="md-btn md-btn-block md-btn-facebook" data-uk-tooltip="{pos:'bottom'}" title="Sign in with Facebook"><i class="uk-icon-facebook uk-margin-remove"></i></a></div>
                            <div class="g-signin2" data-onsuccess="onSignUp"></div>
                            <!--<div><a href="#" class="md-btn md-btn-block md-btn-gplus" data-uk-tooltip="{pos:'bottom'}" title="Sign in with Google+"><i class="uk-icon-google-plus uk-margin-remove"></i></a></div>-->
                        </div>
                        <hr/>
                        <p style="text-align: center !important; font-weight: bold">OR</p>
                        <hr/>
                        <div class="uk-form-row">
                            <label for="register_username">First Name</label>
                            <input class="md-input" type="text" id="register_username" name="fname" />
                        </div>
                        <div class="uk-form-row">
                            <label for="register_username">Last Name</label>
                            <input class="md-input" type="text" id="register_username" name="lname" />
                        </div>
                        <div class="uk-form-row">
                            <label for="register_username">Email</label>
                            <input class="md-input" type="text" id="register_username" name="email" />
                        </div>
                        <div class="uk-form-row">
                            <label for="register_password">Password</label>
                            <input class="md-input" type="password" onkeyup="checkPasswd()" id="register_password" />
                        </div>
                        <div class="uk-form-row">
                            <label for="register_password_repeat">Repeat Password</label>
                            <input class="md-input" type="password" onkeyup="checkPasswd()" id="register_password_repeat" name="password" />
                        </div>

                        <div class="uk-margin-medium-top">
                            <button type="button" id="doreg" class="md-btn md-btn-primary md-btn-block md-btn-large">Sign Up</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
        <div class="uk-margin-top uk-text-center">
            <a id="signup_form_show" href="#">Create an account</a>
        </div>
    </div>
    <script src="<?= base_url('assets_new') ?>/assets/js/common.min.js"></script>
    <script src="<?= base_url('assets_new') ?>/assets/js/uikit_custom.min.js"></script>
    <script src="<?= base_url('assets_new') ?>/assets/js/altair_admin_common.min.js"></script>
    <script src="<?= base_url('assets_new') ?>/assets/js/pages/login.min.js"></script>
    <script>
        $(window).load(function(){
            setTimeout(function(){
                $('#login_password').attr('type','password');
            },500);
        });
        if (typeof(Storage) !== "undefined") {
            var root = document.getElementsByTagName('html')[0],
                theme = localStorage.getItem("altair_theme");
            if(theme == 'app_theme_dark' || root.classList.contains('app_theme_dark')) {
                root.className += ' app_theme_dark';
            }
        }
        function forgotPwd(){
            altair_helpers.content_preloader_show('md');
            $("#errorForget").css("display","none");
            var email = $("#login_email_reset").val();
            if(email == ""){
                $("#errorForget").html("Please Insert Valid Email Address");
                altair_helpers.content_preloader_hide();
            }else{
                $.post("<?= site_url('home/forgotPwd'); ?>",{email:email},function(e){
                    altair_helpers.content_preloader_hide();
                    if(e == "error"){
                        e = "Email not registered";
                    }else if(e == "sent"){
                        e = "An email sent to your email address"
                    }else{
                        e = "An Error Occurred";
                    }
                    $("#errorForget").html(e);
                    $("#errorForget").css("display","");
                });
            }
        }
        function validateCode(){
            var c = $("#codec").val();
            $.post("<?= site_url('home/ajax/validCode'); ?>",{code:c},function(e){
                console.log(e);
                if(e == "Invalid"){
                    $("#errorCode").css("display","");
                    $("#errorCode").html("Code Invalid Or Already Used");
                }else{
                    $("#regField").css("display","");
                    $("#codeFieldDiv").css("display","none");
                    //$("#codec").attr("readonly","");
                    //$("#val").css("display","none");
                }
            });
        }
        function checkPasswd(){
            var p1 = $("#register_password").val();
            var p2 = $("#register_password_repeat").val();
            if(p1 != ''){
                if(p1 != p2){
                    $("#doreg").attr("type","button");
                    $("#doreg").html("Passwords Doesn't Match");
                }else{
                    $("#doreg").attr("type","submit");
                    $("#doreg").html("Create");
                }
            }else{
                $("#doreg").attr("type","button");
                $("#doreg").html("Password Empty");
            }
        }
    </script>
    <script src="https://apis.google.com/js/platform.js" async defer></script>
    <script>
        function onSignIn(googleUser) {
            var profile = googleUser.getBasicProfile();
            var email = profile.getEmail();
            $.post("<?= site_url('home/ajaxLogin') ?>",{email:email},function(e){
                if(e == 'True'){
                    window.location.href = "<?= site_url('home'); ?>";
                }else{
                    signOut();
                    $("#errorrrr").html(e);
                }
            });
        }
        function onSignUp(googleUser) {
            var code = $("#codec").val();
            var profile = googleUser.getBasicProfile();
            var name = profile.getName();
            var email = profile.getEmail();
            $.post("<?= site_url('home/ajaxRegister') ?>",{code:code,email:email,fname:name},function(e){
                if(e == 'True'){
                    window.location.href = "<?= site_url('home'); ?>";
                }else{
                    signOut();
                    window.location.href = "<?= site_url('home'); ?>";
                    //$("#errorrrr").html(e);
                }
            });
        }
        function signOut(){
            var auth2 = gapi.auth2.getAuthInstance();
            auth2.signOut().then(function () {
                console.log('User signed out.');
            });
        }
    </script>
    <script>
        function statusChangeCallback(response) {
            console.log('statusChangeCallback');
            console.log(response);
            if (response.status === 'connected') {
                //testAPI();
                console.log("Connected");
            } else {
                document.getElementById('status').innerHTML = 'Please log ' +
                'into this app.';
            }
        }

        function checkLoginState() {
            FB.getLoginStatus(function(response) {
                statusChangeCallback(response);
            });
        }

        window.fbAsyncInit = function() {
            FB.init({
                appId      : '1451990008166435',
                cookie     : true,  // enable cookies to allow the server to access
                xfbml      : true,  // parse social plugins on this page
                version    : 'v2.8' // use graph api version 2.8
            });
            FB.getLoginStatus(function(response) {
                statusChangeCallback(response);
            });
        };
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));

        function testAPI() {
            FB.login();
            console.log('Welcome!  Fetching your information.... ');
            FB.api('/me?fields=id,name,email', function(response) {
                if (typeof response.id !== 'undefined') {
                    var email = response.id;
                    if(typeof response.email != 'undefined'){
                        email = response.email;
                    }
                    $.post("<?= site_url('home/ajaxLogin') ?>",{email:email},function(e){
                        console.log(e);
                        if(e == 'True'){
                            window.location.href = "<?= site_url('home'); ?>";
                        }else{
                            signOut();
                            $("#errorrrr").html(e);
                        }
                    });
                }
            });
        }
        function testAPIreg() {
            FB.login();
            console.log('Welcome!  Fetching your information.... ');
            FB.api('/me?fields=id,name,email', function(response) {
                if (typeof response.id !== 'undefined') {
                    var email = response.id;
                    if(typeof response.email != 'undefined'){
                        email = response.email;
                    }
                    var code = $("#codec").val();
                    var name = response.name;

                    $.post("<?= site_url('home/ajaxRegister') ?>",{code:code,email:email,fname:name},function(e){
                        if(e == 'True'){
                            window.location.href = "<?= site_url('home'); ?>";
                        }else{
                            signOut();
                            window.location.href = "<?= site_url('home'); ?>";
                            //$("#errorrrr").html(e);
                        }
                    });
                }
            });
        }
    </script>
</body>
</html>