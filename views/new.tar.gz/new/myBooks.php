<div id="page_content">
    <div id="page_content_inner">
        <h4 class="heading_a uk-margin-bottom">My Books</h4>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-medium-8-10">
                <div class="md-card uk-margin-medium-bottom">
                    <div class="md-card-content">
                        <div class="dt_colVis_buttons"></div>
                        <table id="dt_tableExporta" class="uk-table" cellspacing="0" width="100%">
                            <tr>
                                <th>#           </th>
                                <th>Title       </th>
                                <th>Description </th>
                                <th>Image       </th>
                                <th>Read        </th>
                            </tr>
                            <?php $i=1; foreach($myBooks as $val){ ?>
                                <tr>
                                    <td><?= $i; ?></td>
                                    <td><?= $val['title'] ?></td>
                                    <td style="word-break: break-all;"><?= $val['desc'] ?></td>
                                    <td><img src="<?= base_url("assets_f/img")."/".$val['image'] ?>" alt="" style="width:100px"/></td>
                                    <td><a href="<?= base_url("assets_f/img")."/".$val['file'] ?>" target="_blank">Read/Download</a></td>
                                </tr>
                                <?php $i++; } ?>
                        </table>
                    </div>
                </div>

            </div>
            <?php require_once('advert_v.php'); ?>
        </div>
    </div>
</div>

