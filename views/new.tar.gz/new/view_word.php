<div id="page_content">
    <div id="page_content_inner">
        <h4 class="heading_a uk-margin-bottom">Word Log</h4>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-medium-8-10">
                <div class="md-card uk-margin-medium-bottom">
                    <div class="md-card-content">
                        <div class="dt_colVis_buttons"></div>
                        <table id="dt_default" class="uk-table" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <td>Date Posted</td>
                                <td>Preacher Name</td>
                                <td>Topic Preached</td>
                                <td>Message</td>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach($words as $val){ ?>
                                <tr>
                                    <td><?= date("d-M-Y",strtotime($val['date_created'])); ?></td>
                                    <td><?= $val['preacher_name'] ?></td>
                                    <td><?= $val['topic'] ?></td>
                                    <td><a href="<?= site_url('home/view/word_detailed') ?>?id=<?= $val['id'] ?>">View</a></td>
                                </tr>
                            <?php } ?>
                            </tbody>

                        </table>
                    </div>
                </div>

            </div>
            <?php require_once('advert_v.php'); ?>

            <div id="vid"></div>
        </div>
    </div>
</div>

