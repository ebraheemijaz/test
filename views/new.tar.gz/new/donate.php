<div id="page_content">
    <div id="page_content_inner">
        <h3 class="heading_b uk-margin-bottom">Donations</h3>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-medium-8-10">
                <div class="md-card uk-margin-medium-bottom">
                    <div class="md-card-content">
                        <div class="dt_colVis_buttons">
                            <button class="md-btn md-btn-success" data-uk-modal="{target:'#newModal'}">Make a donation</button>
                        </div>
                        <table id="dt_Export" class="uk-table" cellspacing="0" width="100%">
                            <tr>
                                <th>#           </th>
                                <th>Date        </th>
                                <th>Purpose     </th>
                                <th>Description </th>
                                <th>Amount      </th>
                            </tr>
                            <?php $total=0; foreach($donations as $val){ ?>
                                <tr>
                                    <td><?= $val['id'] ?>                   </td>
                                    <td><?= $val['date'] ?>                 </td>
                                    <td><?= $val['detail'] ?>               </td>
                                    <td style="word-break: break-all;"><?= $val['purpose'] ?>  </td>
                                    <td>£<?= $val['amount'] ?>              </td>
                                </tr>
                                <?php $total+=$val['amount']; } ?>
                            <tr>
                                <td colspan="4">Total</td>
                                <td>£ <?= $total ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

            </div>
            <?php require_once('advert_v.php'); ?>

        </div>
    </div>
</div>

<div id="newModal" class="uk-modal">
    <div class="uk-modal-dialog">
        <a href="" class="uk-modal-close uk-close"></a>
        <h1>New Request</h1>
        <?= form_open("home/paypalDonate",array("class"=>"form-horizontal")) ?>
        <div class="form-group">
            Amount:
            <input type="number" min="1" required name="amount" value="1" class="md-input"/>
        </div>
        <div class="form-group">
            Purpose:
            <select class="md-input" name="detail">
                <option value="Offerings">Offerings</option>
                <option value="Tithe">Tithe</option>
                <option value="Food Bank">Food Bank</option>
                <option value="Welfare">Welfare</option>
                <option value="Missionary">Missionary</option>
                <option value="Children">Children</option>
                <option value="Pledge">Pledge</option>
                <option value="Christmas Hamper">Christmas Hamper</option>
                <option value="Others">Other</option>
            </select>
        </div>
        <div class="form-group">
            Additional Information:
            <textarea id="" cols="30" name="purpose" rows="4" class="md-input"></textarea>
        </div>
        <div class="form-group">
            <input type="submit" class="md-btn md-btn-success" value="Donate Now!"/>
        </div>
        </form>
    </div>
</div>
