<div id="page_content">
    <div id="page_content_inner">
        <h4 class="heading_a uk-margin-bottom">Buddies</h4>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-medium-8-10">
                <div class="uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-3 hierarchical_show" data-uk-grid="{gutter: 20, controls: '#products_sort'}">


                    <?php foreach($friends as $val){ ?>
                        <?php if($val['id'] != $userAdmin[0]['id']){ ?>
                            <div data-uk-filter="<?= $val['bgrop'] ?>,<?= $val['fname']." ".$val['lname'] ?>,<?= $val['email'] ?>">
                                <div class="md-card md-card-hover">
                                    <div class="md-card-head">
                                        <div class="uk-text-center">
                                            <?php $image = (empty($val['image'])) ? base_url('assets_f/img/business/avatar.jpg') : base_url('assets_f/img/business')."/".$val['image'] ; ?>
                                            <img class="md-card-head-avatar" src="<?= $image ?>" alt=""/>
                                        </div>
                                        <h3 class="md-card-head-text uk-text-center">
                                            <a href="<?= site_url('home/member') ?>/<?= $val['id'] ?>">
                                                <?= $val['fname']." ".$val['lname'] ?>
                                            </a>
                                            <span class="uk-text-truncate"><?= $val['bgrop'] ?></span>
                                        </h3>
                                    </div>
                                    <div class="md-card-content">
                                        <ul class="md-list">
                                            <li>
                                                <div class="md-list-content">
                                                    <span class="md-list-heading">Info</span>
                                            <span class="uk-text-small uk-text-muted">
                                                <?= substr($val['career'],0,100) ?>
                                            </span>
                                                    <br/>
                                                    <a  href="<?= site_url('home/view/chat#'.$val['id']); ?>">Chat</a>
                                                    <hr/>
                                                    <a target="_blank" href="<?= site_url('business/'.$val['id']); ?>">Business Page</a>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    <?php } ?>
                </div>
            </div>
            <?php require_once('advert_v.php'); ?>
        </div>
    </div>
</div>