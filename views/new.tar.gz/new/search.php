<div id="page_content">
    <div id="page_content_inner">
        <?php require_once('advert_h.php'); ?>
        <h3 class="heading_b uk-margin-bottom">Search</h3>
        <p>(Public Information)</p>
        <div class="md-card uk-margin-medium-bottom">
            <div class="md-card-content">
                <div class="uk-grid" data-uk-grid-margin>
                    <div class="uk-width-medium-1-2">
                        <div class="uk-vertical-align">
                            <div class="uk-vertical-align-middle">
                                <ul id="contact_list_filter" class="uk-subnav uk-subnav-pill uk-margin-remove">
                                    <li class="uk-active" data-uk-filter=""><a href="#">All</a></li>
                                    <!--<li data-uk-filter="goodwin-nienow"><a href="#">Goodwin-Nienow</a></li>-->
                                    <!--<li data-uk-filter="strosin groupa"><a href="#">Strosin Groupa</a></li>-->
                                    <!--<li data-uk-filter="schamberger plc"><a href="#">Schamberger PLC </a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="uk-width-medium-1-2">
                        <label for="contact_list_search">Search... (min 3 char.)</label>
                        <input class="md-input" type="text" id="contact_list_search"/>
                    </div>
                </div>
            </div>
        </div>
        <h3 class="heading_b uk-text-center grid_no_results" style="display:none">No results found</h3>
        <div class="uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4 uk-grid-width-xlarge-1-5 hierarchical_show" id="contact_list">
            <?php foreach($members as $val){ ?>
                <?php if($val['id'] != $userAdmin[0]['id']){ ?>
                    <div data-uk-filter=" <?= $val['bgrop'] ?>,<?= $val['fname']." ".$val['lname'] ?>,<?= $val['fname']." , ".$val['lname'] ?>,<?= $val['email'] ?>">
                        <div class="md-card md-card-hover">
                            <div class="md-card-head">
                                <div class="uk-text-center">
                                    <?php $image = (empty($val['image'])) ? base_url('assets_f/img/business/avatar.jpg') : base_url('assets_f/img/business')."/".$val['image'] ; ?>
                                    <img class="md-card-head-avatar" src="<?= $image ?>" alt=""/>
                                </div>
                                <h3 class="md-card-head-text uk-text-center">
                                    <a href="<?= site_url('home/member') ?>/<?= $val['id'] ?>">
                                        <?= $val['fname']." ".$val['lname'] ?>
                                    </a>
                                    <span class="uk-text-truncate"><?= $val['bgrop'] ?></span>
                                </h3>
                            </div>
                            <div class="md-card-content">
                                <ul class="md-list">
                                    <li>
                                        <div class="md-list-content">
                                            <span class="md-list-heading">Info</span>
                                            <span class="uk-text-small uk-text-muted">
                                                <?= substr($val['career'],0,100) ?>
                                            </span>
                                            <hr/>
                                            <a target="_blank" href="<?= site_url('business/'.$val['id']); ?>">Business Page</a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            <?php } ?>
        </div>

    </div>
    <script>
        <?php if(isset($_GET['q'])){ ?>
        setTimeout(function(){
            $("#contact_list_search").val("<?= $_GET['q'] ?>");
            $("#contact_list_search").keyup();
        },1000);
        <?php } ?>
    </script>

