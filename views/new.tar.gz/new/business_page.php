<?php
$v = $business[0];

//$v = $business[0];
?>
    <div id="page_content">
        <div id="page_content_inner">
            <div class="uk-grid" data-uk-grid-margin data-uk-grid-match id="user_profile">
                <div class="uk-width-large-8-10">
                    <div class="md-card">
                        <div class="user_heading">
                            <div class="user_heading_menu hidden-print">
                                <div class="uk-display-inline-block" data-uk-dropdown="{pos:'left-top'}">
                                    <i class="md-icon material-icons md-icon-light">&#xE5D4;</i>
                                    <div class="uk-dropdown uk-dropdown-small">
                                        <ul class="uk-nav">
                                            <li><a target="_blank" style="cursor:pointer;" class="btn" data-clipboard-text="<?= site_url('business')."/".$v['user_id']; ?>">Copy Link</a></li>
                                            <li><a target="_blank" href="http://www.facebook.com/sharer.php?u=<?= site_url("business")."/".$v['user_id']; ?>">Facebook</a></li>
                                            <li><a target="_blank" href="https://twitter.com/share?url=<?= site_url("business")."/".$v['user_id']; ?>&amp;text=Membership Management System&amp;hashtags=MembershipManagementSystem">Twitter</a></li>
                                            <li><a target="_blank" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?= site_url("business")."/".$v['user_id']; ?>">LinkedIn</a></li>
                                            <li><a target="_blank" href="http://reddit.com/submit?url=<?= site_url("business")."/".$v['user_id']; ?>&amp;title=Membership Management System">Reddit</a></li>
                                            <li><a target="_blank" href="http://www.stumbleupon.com/submit?url=<?= site_url("business")."/".$v['user_id']; ?>&amp;title=Membership Management System">Stumble Upon</a></li>
                                            <li><a target="_blank" href="http://www.tumblr.com/share/link?url=<?= site_url("business")."/".$v['user_id']; ?>&amp;title=Membership Management System">Tumblr</a></li>
                                            <li><a target="_blank" href="mailto:?Subject=Membership Management System&amp;Body=%20 <?= site_url("business")."/".$v['user_id']; ?>">Email</a></li>
                                            <li><a target="_blank" href="https://plus.google.com/share?url=<?= site_url("business")."/".$v['user_id']; ?>">Google+</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="uk-display-inline-block"><i class="md-icon md-icon-light material-icons" id="page_print">&#xE8ad;</i></div>
                                <?php if($v['user_id'] == $userAdmin[0]['id']){ ?>
                                    <a href="#my-disclaimer" data-uk-modal><div class="uk-display-inline-block"><i class="md-icon md-icon-light material-icons">announcement</i></div></a>
                                    <div id="my-disclaimer" class="uk-modal">
                                        <div class="uk-modal-dialog">
                                            <a href="" class="uk-modal-close uk-close"></a>
                                            <h1><?= "Disclaimer"; ?></h1>
                                            <p  style="color:black !important;text-align:justify">
                                                MMS claims no responsibility for any of your contact information displayed here as this area is viewed by all
                                                members and the public at large. Edit and display what you are comfortable for the public to see
                                            </p>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                            <div class="user_heading_avatar">
                                <div class="thumbnail">
                                    <?php $image = (empty($v['logo'])) ? base_url('assets_f/img/business/avatar.jpg') : base_url('assets_f/img/business')."/".$v['logo'] ; ?>
                                    <a href="<?= $image ?>" data-uk-lightbox="{group:'user-photos1'}">
                                        <img src="<?= $image ?>" alt="user avatar"/>
                                    </a>
                                </div>
                            </div>
                            <div class="user_heading_content">
                                <h2 class="heading_b uk-margin-bottom"><span class="uk-text-truncate" id="test"><?= ucfirst($v['title']); ?></span>
                                    <span class="sub-heading"><?= $v['email'] ?></span>
                                </h2>

                            </div>
                            <?php if($v['user_id'] == $userAdmin[0]['id']){ ?>
                                <a class="md-fab md-fab-small md-fab-accent hidden-print" href="<?= site_url('home/view/edit_business') ?>">
                                    <i class="material-icons">&#xE150;</i>
                                </a>
                            <?php } ?>
                        </div>
                        <div class="user_content">
                            <ul id="user_profile_tabs" class="uk-tab" data-uk-tab="{connect:'#user_profile_tabs_content', animation:'slide-horizontal'}" data-uk-sticky="{ top: 48, media: 960 }">
                                <li class="uk-active"><a href="#">About Us</a></li>
                                <li><a href="#">Who We Are</a></li>
                                <li><a href="#">Our Services</a></li>
                                <li><a href="#">Products & Services</a></li>
                                <li><a href="#">Contact Us</a></li>
                            </ul>
                            <ul id="user_profile_tabs_content" class="uk-switcher uk-margin">
                                <li>
                                    <div class="uk-grid uk-margin-medium-top uk-margin-large-bottom" data-uk-grid-margin>
                                        <div class="uk-width-large-1-1">
                                            <h4 class="heading_c uk-margin-small-bottom">Contact Info</h4>
                                            <ul class="md-list md-list-addon">
                                                <li>
                                                    <div class="md-list-addon-element">
                                                        <i class="md-list-addon-icon material-icons">&#xE158;</i>
                                                    </div>
                                                    <div class="md-list-content">
                                                        <span class="md-list-heading"><?= $v['email'] ?></span>
                                                        <span class="uk-text-small uk-text-muted">Email</span>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="md-list-addon-element">
                                                        <i class="md-list-addon-icon material-icons">&#xE0CD;</i>
                                                    </div>
                                                    <div class="md-list-content">
                                                        <span class="md-list-heading"><?= $v['phone']; ?></span>
                                                        <span class="uk-text-small uk-text-muted">Phone</span>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="md-list-addon-element">
                                                        <i class="md-list-addon-icon  material-icons">&#xE8A5;</i>
                                                    </div>
                                                    <div class="md-list-content">
                                                        <span class="md-list-heading"><a href="<?= $v['website']; ?>" target="_blank">Click Here</a></span>
                                                        <span class="uk-text-small uk-text-muted">Website</span>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="md-list-addon-element">
                                                        <i class="md-list-addon-icon  material-icons">&#xE63D;</i>
                                                    </div>
                                                    <div class="md-list-content">
                                                        <span class="md-list-heading"><?= $v['address']; ?></span>
                                                        <span class="uk-text-small uk-text-muted">Address</span>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <h4 class="heading_c uk-margin-small-bottom">Who We Are</h4>
                                    <p>
                                        <?= $v['about'] ?>
                                    </p>
                                </li>
                                <li>
                                    <h4 class="heading_c uk-margin-small-bottom">Our Services</h4>
                                    <p>
                                        <?= $v['services'] ?>
                                    </p>
                                </li>
                                <li>
                                    <h4 class="heading_c uk-margin-small-bottom">Products & Services</h4>
                                    <?php if(!empty($userAdmin)){ ?>
                                        <?php if($userAdmin[0]['id'] != $v['user_id']){ ?>
                                        <?php }else{ ?>
                                            <?= form_open_multipart('home/insert/business_imgs/manage_business',array("class"=>"form-signin","autocomplete"=>"off","style"=>"max-width: 100% !important;")) ?>
                                            <div class="login-wrap">
                                                <div class="col-md-12">
                                                    <input type="file" multiple class="form-control" name="img[]" autofocus>
                                                </div>
                                                <div class="row"></div>
                                                <br/>
                                                <div class="col-lg-offset-4 col-lg-4 col-md-12">
                                                    <button class="btn btn-lg btn-login btn-block" type="submit">Add</button>
                                                </div>
                                                <br/>
                                            </div>
                                            <?= form_close(); ?>
                                        <?php } ?>
                                    <?php } ?>
                                    <?php
                                    $i=1;
                                    if($v['images'] != ""){ ?>
                                        <?php $img = explode("|",$v['images']); ?>
                                        <div id="user_profile_gallery" data-uk-check-display class="uk-grid-width-small-1-2 uk-grid-width-medium-1-3 uk-grid-width-large-1-4" data-uk-grid="{gutter: 4}">
                                            <?php foreach($img as $val){ ?>
                                                <?php if(!empty($val)){ ?>
                                                    <div>
                                                        <a href="<?= base_url("assets_f/img/business") ?>/<?= $val ?>" data-uk-lightbox="{group:'user-photo'}">
                                                            <img src="<?= base_url("assets_f/img/business") ?>/<?= $val ?>" alt=""/>
                                                        </a>
                                                    </div>
                                                <?php } ?>
                                                <?php $i++; } ?>
                                        </div>
                                    <?php } ?>
                                </li>
                                <li>
                                    <h4 class="heading_c uk-margin-small-bottom">Contact Us</h4>
                                    <div class="uk-grid" data-uk-grid-margin>
                                        <div class="uk-width-medium-1-2">
                                            <label for="user_edit_uname_control">Name</label>
                                            <input class="md-input" type="text" id="user_edit_uname_control" name="user_edit_uname_control" />
                                        </div>
                                        <div class="uk-width-medium-1-2">
                                            <label for="user_edit_uname_control">Email</label>
                                            <input class="md-input" type="text" id="user_edit_uname_control" name="user_edit_uname_control" />
                                        </div>
                                    </div>
                                    <div class="uk-grid" data-uk-grid-margin>
                                        <div class="uk-width-medium-1-1">
                                            <label for="user_edit_uname_control">Message</label>
                                            <input class="md-input" type="text" id="user_edit_uname_control" name="user_edit_uname_control" />
                                        </div>
                                    </div>
                                    <div class="uk-grid" data-uk-grid-margin>
                                        <div class="uk-width-medium-1-1">
                                            <button class="md-btn  md-btn-primary">Send</button>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <?php require_once('advert_v.php') ?>
            </div>
        </div>
    </div>
<script>
    function hideMenyeBaar(){
        console.log(1);
        $("#sidebar_main_toggle").click();
    }
    hideMenyeBaar();
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.6.0/clipboard.min.js"></script>

<script>
    var clipboard = new Clipboard('.btn');
    clipboard.on('success', function(e) {
        console.info('Action:', e.action);
        console.info('Text:', e.text);
        console.info('Trigger:', e.trigger);

        e.clearSelection();

        UIkit.notify({
            message : 'Copied',
            status  : 'danger',
            timeout : 2000,
            pos     : 'top-center'
        });

    });
    function copyToClipboard() {
        var $temp = $("<input>");
        $("body").append($temp);
        //console.log(window.location.href);
        //$temp.val("<?//= site_url('business/'.$userAdmin[0]['id']); ?>").select();
        $temp.val(window.location.href).select();
        document.execCommand("copy");
        $temp.remove();
        UIkit.notify({
            message : 'Copied',
            status  : 'danger',
            timeout : 2000,
            pos     : 'top-center'
        });
        //$("#test").click();
    }
//    function addImaage(){
//        $("#addImageModal").modal("toggle");
//    }
</script>

