<div id="page_content">
    <div id="page_content_inner">
        <h4 class="heading_a uk-margin-bottom">Advert</h4>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-medium-10-10">
                <div class="md-card uk-margin-medium-bottom">
                    <div class="md-card-content" data-step="1" data-intro="Your Advert Orders">
                        <div class="dt_colVis_buttons" data-step="2" data-intro="Click This To Adjust Visibility of columns"></div>
                        <table id="dt_colVis" class="uk-table" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>#                   </th>
                                    <th>Horizontal Banner   </th>
                                    <th>Vertical Banner     </th>
                                    <th>Requested On        </th>
                                    <th>Payment Status      </th>
                                    <th>Advert Starting Date</th>
                                    <th>Advert Status       </th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $i=1; foreach($advert as $val){ ?>
                                <tr>
                                    <td><?= $i; ?></td>
                                    <td><a target="_blank" href="<?= base_url("assets_f")."/img/business/".$val['horizontal'] ?>">See</a></td>
                                    <td><a target="_blank" href="<?= base_url("assets_f")."/img/business/".$val['vertical'] ?>">See</a></td>
                                    <td><?= $val['date'] ?></td>
                                    <td>
                                        <?php if($val['status'] == "unpaid"){ ?>
                                            <span class="md-btn md-btn-danger"><?= $val['status'] ?></span>
                                            <a href="<?= site_url('home/activateAdv/'.$val['id']); ?>"><span class="md-btn md-btn-info">Pay</span></a>
                                        <?php }else{ ?>
                                            <span class="md-btn md-btn-success"><?= $val['status'] ?></span>
                                        <?php } ?>
                                    </td>
                                    <td><?= $val['starting'] ?></td>
                                    <td>Inactive</td>
                                </tr>
                                <?php $i++; } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

