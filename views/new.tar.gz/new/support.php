<div id="page_content">
    <div id="page_content_inner">
        <h3 class="heading_b uk-margin-bottom">Support</h3>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-medium-8-10">
                <div class="md-card uk-margin-medium-bottom" >
                    <div class="md-card-content">
                        <h3 class="heading_a">Get in touch with us!</h3>
                        <br/>
                        <form method="post" action="<?= site_url('home/insert/support/index'); ?>">
                            <div class="uk-form-row">
                                <div class="uk-width-medium-1-1">
                                    <label>Subject Matter</label>
                                    <input type="text" name="subject" required class="md-input" />
                                </div>
                            </div>
                            <div class="uk-form-row">
                                <div class="uk-width-medium-1-1">
                                    <label>Description</label>
                                    <textarea required name="description" class="md-input"></textarea>
                                </div>
                            </div>
                            <div class="uk-form-row">
                                <span class="uk-input-group-addona">
                                    <button type="button" onclick="sendSupport()" class="md-btn md-btn-danger">Send</button>
                                </span>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
            <?php require_once("advert_v.php"); ?>
        </div>
    </div>
</div>

<script>
    function sendSupport(){
        var sub = $("[name=subject]").val();
        var msg = $("[name=description]").val();
        if(sub == "" || msg == ""){
            UIkit.notify({
                message : 'Please Complete the required information',
                status  : 'danger',
                timeout : 2000,
                pos     : 'top-center'
            });
        }else{
            $.post("<?= site_url('home/ajaxSupport') ?>",{subject:sub,message:msg},function(e){
                //console.log(e);
                UIkit.notify({
                    message : 'Message Delivered – Thank You',
                    status  : 'danger',
                    timeout : 2000,
                    pos     : 'top-center'
                });
            });

        }
    }
</script>
