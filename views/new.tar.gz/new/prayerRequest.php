<div id="page_content">
    <div id="page_content_inner">
        <h3 class="heading_b uk-margin-bottom">Prayer Requests</h3>
        <div class="uk-grid uk-grid-medium" data-uk-grid-margin data-uk-grid-match="{target:'.md-card'}">
            <div class="uk-width-medium-8-10">
                <div class="md-card uk-margin-medium-bottom">
                    <div class="md-card-content">
                        <div class="dt_colVis_buttons">
                            <button class="md-btn md-btn-success" data-uk-modal="{target:'#newModal'}">New Request</button>
                        </div>
                        <table id="dt_Export" class="uk-table" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <td>#</td>
                                <td style="width: 90px">Date</td>
                                <td>Description</td>
                                <td>Priority</td>
                                <td>Action</td>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $i=1; foreach($p_request as $val){ ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?= date("d-M-Y",strtotime($val['date'])); ?></td>
                                    <td style="word-break: break-all;">
                                        <?= substr($val['desc'],0,100); ?>
                                        <a href="#my-id<?= $val['id'] ?>" data-uk-modal><span class="md-btn-primary">Read More</span></a>
                                    </td>
                                    <td><?= ucfirst($val['priority']) ?></td>
                                    <td><a href="<?= site_url('home/delete') . "/" . $val['id']."/same" ?>">Delete</a></td>
                                </tr>
                                <div id="my-id<?= $val['id'] ?>" class="uk-modal">
                                    <div class="uk-modal-dialog">
                                        <a href="" class="uk-modal-close uk-close"></a>
                                        <h1><?= "Prayer Request"; ?></h1>
                                        <p style="word-break: break-all">
                                            <?= $val['desc'] ?>
                                        </p>
                                    </div>
                                </div>
                                <?php $i++; } ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
            <?php require_once('advert_v.php'); ?>

        </div>
    </div>
</div>

<div id="newModal" class="uk-modal">
    <div class="uk-modal-dialog">
        <a href="" class="uk-modal-close uk-close"></a>
        <h1>New Request</h1>
        <?= form_open("home/insert/p_request/prayerRequest?id=1",array('class'=>"form-horizontal")) ?>
        <div class="form-group">
            Priority:
            <select name="priority" id="" class="md-input">
                <option value="normal">Normal</option>
                <option value="urgent">Urgent</option>
            </select>
        </div>
        <div class="form-group">
            Description:
            <textarea required id="" cols="30" rows="4" name="desc" class="md-input"></textarea>
            <span id="textLe">0</span>/500
        </div>
        <div class="form-group">
            <input type="submit" class="md-btn md-btn-success" value="Request Now!"/>
        </div>
        </form>
    </div>
</div>
<script>
    $("[name='priority']").change(function(){
        var a = $("[name='priority']").val();
        if(a == 'urgent'){
            $("[name='desc']").attr('placeholder',"Description and please include your contact number for our prayer team to contact you");
        }else{
            $("[name='desc']").attr('placeholder',"Description");
        }
    })
</script>
<script>
    $("[name=desc]").keyup(function(){
        var a = $("[name=desc]").val();
        $("[name=desc]").val(a.substring(0,500));
        lenght = a.length;
        $("#textLe").html(lenght);
    });
</script>
<script>
    <?php if(isset($_GET['received'])){ ?>
    setTimeout(function(){
        UIkit.notify({
            message : 'Prayer Request Submitted – Your Joy shall be full IJMN',
            status  : 'danger',
            timeout : 2000,
            pos     : 'top-center'
        });
    },1000);
    <?php } ?>
</script>
