
<div class="uk-width-medium-2-10">
    <div class="md-card uk-margin-medium-bottom">
        <div class="md-card-content">
            <h3 class="heading_a uk-margin-bottom">Advertisement</h3>
            <div class="uk-slidenav-position" data-uk-slider>
                <div class="uk-slider-container">
                    <ul class="uk-slider uk-grid uk-grid-small uk-grid-width-medium-1-4 uk-grid-width-small-1-2">
                        <li class="uk-width-1-1" style="height:600px;background: url('<?= base_url('assets_b/ad2.jpg'); ?>');background-size:100% 100%;"></li>
                        <li class="uk-width-1-1" style="height:600px;background: url('<?= base_url('assets_b/ad1.jpg'); ?>');background-size:100% 100%;"></li>
                    </ul>
                </div>
                <a href="#" class="uk-slidenav uk-slidenav-contrast uk-slidenav-previous" data-uk-slider-item="previous"></a>
                <a href="#" class="uk-slidenav uk-slidenav-contrast uk-slidenav-next" data-uk-slider-item="next"></a>
            </div>
        </div>
    </div>
</div>
